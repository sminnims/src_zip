package com.ckbs.uidemo;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import org.snmp4j.CommunityTarget;
import org.snmp4j.MessageDispatcher;
import org.snmp4j.PDU;
import org.snmp4j.PDUv1;
import org.snmp4j.Session;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.event.ResponseListener;
import org.snmp4j.mp.MPv3;
import org.snmp4j.mp.PduHandle;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.security.SecurityLevel;
import org.snmp4j.security.SecurityModel;
import org.snmp4j.security.SecurityModels;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.GenericAddress;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class SnmpManager {
	
	//public static ArrayList<DeviceItem> deviceList;
	//public static DeviceItem deviceItem;
	
	private static HashMap<String,String> deviceItem;
	public static ArrayList<HashMap<String,String>> deviceList = new ArrayList<HashMap<String,String>>();	
	
	static Handler mHandler;	
	SnmpManager(Handler h) {
		mHandler = h;
	}
	
	static Message msg;
	
	private static final String TAG = "[SNMP_MANAGER]";
	
	public static String SNMP_IP = "";	
	public final static int SNMP_PORT = 161;
	public static String SNMP_ADDR = "";
	
	private final static String BC_ADDR = "udp:255.255.255.255/161";
	private final static int SNMP_VERSION = SnmpConstants.version1;
	private final static String OID_ENTERPRISES = "1.3.6.1.4.1";//DevName
	private final static String OID_DEVICE_NAME = OID_ENTERPRISES + ".1602.1.1.1.1.0";//DevName	
	private final static String OID_DEVICE_IP = OID_ENTERPRISES + ".1602.1.3.3.1.2.1.1.2.1";//DevName
	
	private final static String community = "public";// canon only : canon_admin
	private final static String canonCommnunity = "canon_admin";
	private static Snmp mSnmp;

	public static void setIP(String ip) {
		
		SNMP_IP = "";
		SNMP_IP = ip;
		SNMP_ADDR = SNMP_IP + "/" + SNMP_PORT;		
	}
	
	public static Snmp getSNMP() throws IOException {
		
		if(mSnmp == null)
			mSnmp = new Snmp();
		
		return mSnmp;
	}
	
	public static void findSnmpDevice(){
		
		try {
			TransportMapping transport = new DefaultUdpTransportMapping();
			Session findSnmp = new Snmp(transport);
			USM usm = new USM(SecurityProtocols.getInstance(), new OctetString(MPv3.createLocalEngineID()),0);
			SecurityModels.getInstance().addSecurityModel(usm);
			((Snmp) findSnmp).listen();
			
			Address broadcastAddr = GenericAddress.parse(BC_ADDR);
			
			CommunityTarget broadcastTarget = new CommunityTarget();
			broadcastTarget.setCommunity(new OctetString(canonCommnunity));
			broadcastTarget.setAddress(broadcastAddr);
			broadcastTarget.setRetries(2);
			broadcastTarget.setTimeout(1000);;
			broadcastTarget.setVersion(SNMP_VERSION);
			
			PDU pdu = new PDU();
			pdu.add(new VariableBinding(new OID(OID_DEVICE_NAME)));//new int[] {1,3,6,1,2,1,1,1,0})));;
			pdu.add(new VariableBinding(new OID(OID_DEVICE_IP)));//new int[] {1,3,6,1,2,1,1,2,0})));;
			
			class MyResponseListener implements ResponseListener {

				boolean finished = false;				  
				  
				public void onResponse(ResponseEvent event) {
					  					  
					  if(event.getResponse()!=null)
					  {
						  String deviceName = "";
						  String deviceIP = "";
						  //Log.i("Received response PDU is: ", event.getResponse().toString());
						  PDU pduR = event.getResponse();
						  deviceName = pduR.getVariableBindings().firstElement().toString();
							if(deviceName.contains("="))
							{
								int len = deviceName.indexOf("=");
								deviceName = deviceName.substring(len+1, deviceName.length());
							}		
						  Log.i("GET_DEVICE_NAME", deviceName);
						  deviceIP = pduR.getVariableBindings().lastElement().toString();
							if(deviceIP.contains("="))
								{
								int len = deviceIP.indexOf("=");
								deviceIP = deviceIP.substring(len+1, deviceIP.length());
							}
						  Log.i("GET_DEVICE_IP", deviceIP);
						  deviceItem = new HashMap<String,String>();
						  deviceItem.put("device",  deviceName);
						  deviceItem.put("ip", deviceIP);
						  deviceList.add(deviceItem);
					  }
				     if (event.getResponse() == null) {
				       finished = true;
				       //listener.notify(); Snmp.notify() //SNMPv2c, SNMPv3
				     }
				   }
				 
				   public boolean isFinished() {
				     return finished;
				   }
				 };
			MyResponseListener listener = new MyResponseListener();
			
			findSnmp.send(pdu,  broadcastTarget, null, listener);
			try{
				while(!listener.isFinished()){
					
					synchronized(listener){
					listener.wait(broadcastTarget.getTimeout()*2);
					}
				
				}
			}catch(InterruptedException iex){
				Log.e("BroadCastSnmp", iex.getMessage().toString());
			}
			
			if(findSnmp != null)
				findSnmp.close();
					
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
		
	public static String snmpGet(int cmd)
	{
		String str = "";
		String mOID = "";
		switch(cmd)
		{
		case ManualSearchActivity.SNMP_CMD_GET_DEVICE_NAME:
			mOID = OID_DEVICE_NAME;
			break;
		case ManualSearchActivity.SNMP_CMD_GET_DEVICE_IP:
			mOID = OID_DEVICE_IP;			
		default:
			break;
		}
		try{
			Snmp gSnmp;
			OctetString oCommunity = new OctetString(canonCommnunity);
			Address targetAddr = new UdpAddress(SNMP_ADDR);
			TransportMapping transport = new DefaultUdpTransportMapping();
			transport.listen();
			Log.i("OctetString : ", oCommunity.toString());
			CommunityTarget comTarget = new CommunityTarget();
			comTarget.setCommunity(oCommunity);
			comTarget.setVersion(SNMP_VERSION);
			comTarget.setAddress(targetAddr);
			comTarget.setRetries(2);
			comTarget.setTimeout(1000);
			
			PDU pdu = new PDU(); 
			ResponseEvent response = null;
			pdu.add(new VariableBinding(new OID(mOID)));
			pdu.setType(PDU.GET);
			gSnmp = new Snmp(transport);
			Log.i("SNMP Create",gSnmp.toString());
			response = gSnmp.get(pdu, comTarget);
			
			if(response != null)
			{
				if(response.getResponse() != null)
				{
					if(response.getResponse().getErrorStatusText().equalsIgnoreCase("Success"))
					{
						Log.i("SNMP_RESPONSE", response.toString());
						PDU pduResponse = response.getResponse();
						Log.i("PDU", pduResponse.toString());
						
						str = pduResponse.getVariableBindings().firstElement().toString();
						Log.i("PDU_STRING", str);
						
						if(str.contains("="))
						{
							int len = str.indexOf("=");
							str = str.substring(len+1, str.length());
						}
						
						msg = mHandler.obtainMessage(ManualSearchActivity.MSG_SNMP_CMD_SUCCESS);
						mHandler.sendMessage(msg);
						
					}					
				}else
				{
					Log.e(TAG, "CAN NOT GET RESPONSE");
					msg = mHandler.obtainMessage(ManualSearchActivity.MSG_SNMP_CMD_NO_RESPONSE);
					mHandler.sendMessage(msg);
				}
								
			}else
			{
				Log.e(TAG, "TimeOut");
			}
			
			if(gSnmp != null)
				gSnmp.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return str;
		
	}
	
}

