package com.ckbs.uidemo;

public class CopyCommand {
	
	public final static int CMD_IDENT = 0;
	public final static int CMD_CMD = 1;
	public final static int CMD_OPT1 = 2;
	public final static int CMD_OPT2 = 3;
	
	private int msgIdent;
	private int msgCmd;
	private int msgOpt1;
	private int msgOpt2;
	
	public CopyCommand() {
		init();
	}
	
	public void setCmd(byte[] src)//(int ident, int val)
	{
		byte[] tmpArr = new byte[4];
		System.arraycopy(src, 0, tmpArr,  0,  4);
		msgIdent = DataControl.byte2int(tmpArr);		
		if(msgIdent == 1)
		{
			tmpArr = new byte[4];
			System.arraycopy(src, 4, tmpArr,  0,  4);
			msgCmd = DataControl.byte2int(tmpArr);
			
			tmpArr = new byte[4];
			System.arraycopy(src, 8, tmpArr,  0,  4);
			msgOpt1 = DataControl.byte2int(tmpArr);
			
			tmpArr = new byte[4];
			System.arraycopy(src, 12, tmpArr,  0,  4);
			msgOpt2 = DataControl.byte2int(tmpArr);
		}
	}
	
	
	public int getCmd(int ident)
	{
		switch(ident)
		{
			case CMD_IDENT:
				return msgIdent;
			case CMD_CMD:
				return msgCmd;
			case CMD_OPT1:
				return msgOpt1;
			case CMD_OPT2:
				return msgOpt2;
			default:
				return -1;
		}				
	}
	
	public void init() {
		msgIdent = 1;
		msgCmd = 1;
		msgOpt1 = 1;
		msgOpt2 = 0;
	}
	
	public int getInt(byte[] data) {
		int rtn = 0;
		int[] data2 = new int[4];
		for(int i = 0; i < 4; i++)
		{
			data2[i] = data[i] < 0 ? ((Byte.MAX_VALUE+1)*2) + data2[i] : data[i];
			rtn |= ( data2[i] << (8*(3-i)));
		}
		return rtn;
	}

}