package com.ckbs.uidemo;

import java.io.IOException;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TableRow;

public class MainActivity extends Activity {
	
	ImageButton copyBtn, scanBtn, faxBtn, configBtn, greenLed, redLed; 
	
	Message deviceStatusMsg;
	
	FrameLayout drawScreen;
	
	LedManageThread mLedManagerThread;
	
	TableRow tb1;
	
	SocketListener mSL;

	//Button copyBtn, scanBtn, faxBtn, configBtn;


	public static final int MSG_DEVICE_CONNECTED = 2;
	public static final int MSG_DEVICE_CONNECTING = 1;
	public static final int MSG_DEVICE_DISCONNECTED = 4;
	public static final int MSG_DEVICE_ERR1 = 5;
	public static final int MSG_DEVICE_PRINTING = 3;
	public final static int MSG_GREEN_LED_OFF = 7;
	public final static int MSG_GREEN_LED_ON = 6;
	public final static int MSG_PRINT_CLOSE = 10;
	public final static int MSG_RED_LED_OFF = 9;
	public final static int MSG_RED_LED_ON = 8;
	public static final int MSG_STOP_DONE = 0;
	public final static int ON_KEYBOARD_BACK_PROC = 11;
	
	protected void onPause() {
		
		super.onPause();
		//	mSL.interrupt();
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);		
		
		copyBtn = (ImageButton)findViewById(R.id.copyB1tn);
		faxBtn = (ImageButton)findViewById(R.id.printBtn);
		scanBtn = (ImageButton)findViewById(R.id.faxBtn);
		configBtn = (ImageButton)findViewById(R.id.configBtn);
		
		greenLed = (ImageButton)findViewById(R.id.greenLed);
		redLed = (ImageButton)findViewById(R.id.redLed);
		
		greenLed.setEnabled(false);
		redLed.setEnabled(false);
		
		//redLed.setClickable(true);
		
		tb1 = (TableRow)findViewById(R.id.tableRow1);
		
		copyBtn.setOnClickListener(btnListener);
		faxBtn.setOnClickListener(btnListener);
		scanBtn.setOnClickListener(btnListener);
		configBtn.setOnClickListener(btnListener);
		
		mLedManagerThread = new LedManageThread(mHandler);
		mLedManagerThread.setDaemon(true);
		mLedManagerThread.start();
		
		deviceStatusMsg = mLedManagerThread.msgGetHandler.obtainMessage(MainActivity.MSG_DEVICE_CONNECTED);
		mLedManagerThread.msgGetHandler.sendMessage(deviceStatusMsg);
		
		//getMsgFromSocket();
	}
	
    public void getMsgFromSocket()
    {
	//	new Thread(new Runnable(){
	//		@Override
	//		public void run(){  				
		    	mSL = new SocketListener(getApplicationContext(), mHandler);
		    	mSL.start();				
		//	}
	//	}).start();
    }
 
	private OnClickListener btnListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
    		switch(v.getId()){
    		case R.id.copyB1tn:
    			Intent mIntent = new Intent(MainActivity.this, CopyMainActivity.class);
    			startActivity(mIntent);
    			
    			break;
    		case R.id.printBtn:


    			break;
    		case R.id.faxBtn:


    			break;
    		case R.id.configBtn:
    			break;

    		default:
    			break;
    				
    		}
		}
		
	};

	final Handler mHandler = new Handler()
	{
		@Override
		public void handleMessage(Message msg)
		{    					
			switch(msg.what)
			{
				case MainActivity.MSG_STOP_DONE:

					break;
					
				case MainActivity.MSG_GREEN_LED_ON:
					greenLed.setEnabled(true);
					break;
					
				case MainActivity.MSG_GREEN_LED_OFF:
					greenLed.setEnabled(false);
					break;
					
				case MainActivity.MSG_RED_LED_ON:
					redLed.setEnabled(true);
					break;
					
				case MainActivity.MSG_RED_LED_OFF:
					redLed.setEnabled(false);
					break;
					
				default:
					break;						
			}
		}
			
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}

