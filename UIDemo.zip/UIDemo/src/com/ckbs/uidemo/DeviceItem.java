package com.ckbs.uidemo;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
/*
public class DeviceItem {
	
	private String deviceName = "";
	private String deviceIP = "";
	
	public String getName(){
		if(deviceName != null)
		return deviceName;	
		else
			return "ERR";
	}
	
	public String getIP(){
		if(deviceIP != null)			
		return deviceIP;
		else
			return "0.0.0.0";
	}
	
	public void setData(String name, String ip) {
		deviceName = name;
		deviceIP = ip;
	}
	
	public void clean() {
		deviceName = "";
		deviceIP = "";
	}
	
	public void prnItem() {
		Log.i("TEST", deviceName);
		Log.i("TEST", deviceIP);
	}
}
*/

public class DeviceItem implements Parcelable{

	private String deviceName = "";
	private String deviceIP = "";
	
	public void prnItem(){
		Log.i("NAME", deviceName);
		Log.i("IP", deviceIP);
	}
	
	public String getName() {
		return deviceName;
	}
	
	public String getIP() {
		return deviceIP;
	}
	
	public DeviceItem() {
		
	}
	
	public DeviceItem(Parcel in) {
		readFromParcel(in);
	}
	
	public void clean()
	{
		deviceName = "";
		deviceIP = "";
	}
	
	public void setData(String name, String ip)
	{
		deviceName = name;
		deviceIP = ip;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		// TODO Auto-generated method stub
		dest.writeString(deviceName);
		dest.writeString(deviceIP);
	}
	

	private void readFromParcel(Parcel in)
	{
		deviceName = in.readString();
		deviceIP = in.readString();
	}
	
	public static final Parcelable.Creator CREATOR = new Parcelable.Creator(){
		public DeviceItem createFromParcel(Parcel in) {
			return new DeviceItem(in);
		}
		
		public DeviceItem[] newArray(int size) {
			return new DeviceItem[size];
		}
	};
}
