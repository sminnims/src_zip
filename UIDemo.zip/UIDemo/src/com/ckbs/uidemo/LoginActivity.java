package com.ckbs.uidemo;

import java.io.IOException;
import java.util.regex.Pattern;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {
	
	String idText, pwText;
	EditText idTextBox, pwTextBox;
	
	Button loginBtn;
	
	ProgressDialog loginDialog;
	
	View tLayout;	
	
	SocketListener mSocketListener;
	
	//SocketListener mSocketListener;
	
	private static boolean DEBUG = true;
	
	@Override
	protected void onPause() {
		
		super.onPause();
		if(mSocketListener.isAlive())
			mSocketListener.interrupt();
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_login);
		
		idTextBox = (EditText)findViewById(R.id.idTextBox);
		pwTextBox = (EditText)findViewById(R.id.pwTextBox); 
				
		loginBtn = (Button)findViewById(R.id.loginBtn);
		loginBtn.setOnClickListener(btnListener);
		
		idTextBox.setFilters(new InputFilter[] {textFilter});
		pwTextBox.setFilters(new InputFilter[] {textFilter});
		
		tLayout = findViewById(R.id.upperMenuLayout);
		
		tLayout.requestFocus();
		
		pwTextBox.setOnClickListener(cListener);
		
		pwTextBox.setImeOptions(EditorInfo.IME_ACTION_DONE);
		
		pwTextBox.setOnEditorActionListener(new TextView.OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					
					loginBtnClick();
					
					break;
				}
				return false;
			}
		
		});
		
		getMsgFromSocket();
	}
	
    public void getMsgFromSocket()
    {
		new Thread(new Runnable(){
			@Override
			public void run(){  				
		    	mSocketListener = new SocketListener(getApplicationContext(), mHandler);
		    	mSocketListener.start();				
			}
		}).start();
    }
	
	private OnClickListener btnListener = new OnClickListener(){
    	@Override
		public void onClick(View v){
    		switch(v.getId()){
    		case R.id.loginBtn:
    			loginBtnClick();

    			break;
    			
    		default:
    			break;   				
    		}
    	}
    };
	private OnClickListener cListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			Toast.makeText(LoginActivity.this, getString(R.string.invalid_id_input), Toast.LENGTH_SHORT).show();
			// TODO Auto-generated method stub
			idText = idTextBox.getText().toString();
			if(idText.getBytes().length <= 0)
			{
				Toast.makeText(LoginActivity.this, getString(R.string.invalid_id_input), Toast.LENGTH_SHORT).show();
				idTextBox.requestFocus();
			}else
			{
				
			}
			
		}
	
	};

	
	/*
	 * 공백문자입력제한
	 */
	public InputFilter textFilter = new InputFilter() {
		@Override
		public CharSequence filter(CharSequence source, int start, int end,
				Spanned dest, int dstart, int dend) {
			// TODO Auto-generated method stub
			Pattern ps = Pattern.compile("[ ]+$");
			if(ps.matcher(source).matches())
			{
				return "";
			}
			return null;
		}
		
	};
	

    private void loginBtnClick()
	{
		if(DEBUG)
		{
			idText = "test"; pwText = "test";
		}else
		{
			idText = idTextBox.getText().toString();
			pwText = pwTextBox.getText().toString();
		}
		
		//if(idText.valid && pwText.valid)
		if(idText.getBytes().length > 0 && pwText.getBytes().length > 0)
		{		
			loginDialog = ProgressDialog.show(LoginActivity.this, "Process",
													getString(R.string.login_process), true);
			new Thread(new Runnable(){
				@Override
				public void run(){
					/*
					 * Send Login MSG and wait until get response 
					 */					
					try{						
						Thread.sleep(1500);
						//SocketManager.sendMsg("TEST");
					} catch(Exception e){}
					loginDialog.dismiss();
					Intent mIntent = new Intent(LoginActivity.this, MainActivity.class);
					startActivity(mIntent);
					finish();
				}
			}).start();

		}else if(idText.getBytes().length <= 0)
		{
			Toast.makeText(LoginActivity.this, getString(R.string.invalid_id_input), Toast.LENGTH_SHORT).show();
		}else if(pwText.getBytes().length <= 0)
		{

			Toast.makeText(LoginActivity.this, getString(R.string.invalid_pw_input), Toast.LENGTH_SHORT).show();
		}
		
	}
    
	public Handler mHandler  = new Handler(){
		
		@Override
		public void handleMessage(Message msg){
			switch(msg.what)
			{
			case 0:
				/*
				 * Login OK MSG. start Next Activity
				 */
				
				break;
				
			case 1:
				/*
				 * Login Fail(invalid id) MSG. Toast alert.
				 */
				break;
				
			case 2:
				/*
				 * Login Fail(invalid pw) MSG. Toast alert.
				 */
			default:
					break;
			}
		}
	};

}
