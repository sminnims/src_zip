/*
 * Extend EditText Class
 * custom processing back key event
 */

package com.ckbs.uidemo;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.EditText;

public class exEditText extends EditText{
	
	private Handler handler = null;
	
	public exEditText(Context c) {
		super(c);
	}
	
	public exEditText(Context c, AttributeSet attrs) {
		super(c, attrs);
	}
	
	public exEditText(Context c, AttributeSet attrs, int defStyle) { 
		super(c, attrs, defStyle);
	}
	
	@Override
	public boolean onKeyPreIme(int keyCode, KeyEvent event) {

		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			Log.i("exEditText", "start1");
			if (handler != null) {

				if (event.getAction() == KeyEvent.ACTION_DOWN) {
					Log.i("exEditText", "start2");
					Message msg;
					msg = handler.obtainMessage(MainActivity.ON_KEYBOARD_BACK_PROC);
					handler.sendMessage(msg);					
				}
			}

			return false;
		}

		return super.dispatchKeyEvent(event);
	}
	
	public void setOnBackPressedHandler(Handler handler) {
		this.handler = handler;
	}
}
