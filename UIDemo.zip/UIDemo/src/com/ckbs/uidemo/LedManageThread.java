package com.ckbs.uidemo;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

public class LedManageThread extends Thread{

	class LedControlThread extends Thread{
		
		boolean flags;
		Message msg;
		int mState;
		Handler myHandler;
		
		/*
		 * Temp var
		 * pCounter : Printing LED Signal 카운터
		 */
		
		int pCounter = 0;
		
		LedControlThread(Handler h)
		{
			myHandler = h;
		}

		@Override
		public void run() {
			
			Log.i("Announce", "THREAD1 RUN!!!");
			flags = true;
			switch(mState)
			{			
				case STATE_CONNECTING:
					while(flags)
					{
						msg = myHandler.obtainMessage(MainActivity.MSG_GREEN_LED_ON);
						myHandler.sendMessage(msg);
						try {
							Thread.sleep(200);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						msg = myHandler.obtainMessage(MainActivity.MSG_GREEN_LED_OFF);
						myHandler.sendMessage(msg);
						try {
							Thread.sleep(50);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}					
					}
					break;
		
				case STATE_CONNECTED:
					for(int i = 0; i < 3; i++)
					{
						msg = myHandler.obtainMessage(MainActivity.MSG_GREEN_LED_ON);
						myHandler.sendMessage(msg);
						try {
							Thread.sleep(400);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						msg = myHandler.obtainMessage(MainActivity.MSG_GREEN_LED_OFF);
						myHandler.sendMessage(msg);
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}						
					}
					msg = myHandler.obtainMessage(MainActivity.MSG_GREEN_LED_ON);
					myHandler.sendMessage(msg);
					break;
				
				case STATE_PRINTING:
					while(flags && (pCounter < 10))
					{
						msg = myHandler.obtainMessage(MainActivity.MSG_GREEN_LED_ON);
						myHandler.sendMessage(msg);
						try {
							Thread.sleep(800);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						msg = myHandler.obtainMessage(MainActivity.MSG_GREEN_LED_OFF);
						myHandler.sendMessage(msg);
						try {
							Thread.sleep(200);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						pCounter++;
					}
					if(flags)
					{
						msg = myHandler.obtainMessage(MainActivity.MSG_GREEN_LED_ON);
						myHandler.sendMessage(msg);
					}else
					{
						Log.i("printingThread", "Forced Close");
					}
					Log.i("Printing", "OUT");
					break;
				case STATE_ERR1:
					
					msg = myHandler.obtainMessage(MainActivity.MSG_GREEN_LED_OFF);
					myHandler.sendMessage(msg);
					
					while(flags)
					{
						msg = myHandler.obtainMessage(MainActivity.MSG_RED_LED_ON);
						myHandler.sendMessage(msg);
						try {
							Thread.sleep(200);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						msg = myHandler.obtainMessage(MainActivity.MSG_RED_LED_OFF);
						myHandler.sendMessage(msg);
						try {
							Thread.sleep(50);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}					
					}
					break;
		}
			Log.i("Announce", "Thread1 OUT");
		}
		
		
	}
	final static int STATE_CONNECTED = 1;
	final static int STATE_CONNECTING = 0;

	final static int STATE_DISCONNETED = 2;
	final static int STATE_ERR1 = 4;
	final static int STATE_PRINTING = 3;
	LedControlThread mLedControlThread;
	public Handler msgGetHandler = new Handler(){
		
		@Override
		public void handleMessage(Message msg){
			
			Message retMsg = new Message();
			
			switch(msg.what)
			{
			case MainActivity.MSG_DEVICE_CONNECTING:
				/*
				 * Green Led Blink(FAST)
				 */
				Log.i("Notice", "Start MSG_DEVICE_CONNECTING");
				if(mLedControlThread != null && mLedControlThread.isAlive())
				{
					Log.i("Notice", "Change Thread Flag");
					mLedControlThread.flags = false;
				}
				while(mLedControlThread != null && mLedControlThread.isAlive())
				{
					
				}
				Log.i("Notice", "Start MSG_DEVICE_CONNECTING");
				mLedControlThread = new LedControlThread(msgSendHandler);
				mLedControlThread.setDaemon(true);
				mLedControlThread.mState = STATE_CONNECTING;
				mLedControlThread.start();
				break;
				
			case MainActivity.MSG_DEVICE_CONNECTED:
				/*
				 * Green Led On
				 */
				if(mLedControlThread != null && mLedControlThread.isAlive())
				{
					Log.i("Notice", "Change Thread Flag");
					mLedControlThread.flags = false;
				}
				while(mLedControlThread != null && mLedControlThread.isAlive())
				{
					Log.i("Notice", "Waiting close thread");
				}
				mLedControlThread = new LedControlThread(msgSendHandler);
				mLedControlThread.setDaemon(true);
				mLedControlThread.mState = STATE_CONNECTED;
				mLedControlThread.start();
				break;
				
			case MainActivity.MSG_DEVICE_PRINTING:
				/*
				 * Green Led Blink(SLOW)
				 */				
				if(mLedControlThread != null && mLedControlThread.isAlive())
				{
					mLedControlThread.flags = false;
					Log.i("Interrupt", "DEVICE_PRINTING");
				}while(mLedControlThread != null && mLedControlThread.isAlive())
				{
					Log.i("Notice", "Waiting close thread");
				}
				mLedControlThread = new LedControlThread(msgSendHandler);
				mLedControlThread.setDaemon(true);
				mLedControlThread.mState = STATE_PRINTING;
				mLedControlThread.start();
				break;
				
			case MainActivity.MSG_DEVICE_DISCONNECTED:
				/*
				 * Green Led Off
				 */
				break;
			case MainActivity.MSG_DEVICE_ERR1:
				/*
				 * Red Led Blink
				 */		
				if(mLedControlThread != null && mLedControlThread.isAlive())
				{
					mLedControlThread.flags = false;
					Log.i("Interrupt", "DEVICE_ERR1");
				}while(mLedControlThread != null && mLedControlThread.isAlive())
				{
					Log.i("Notice", "Waiting close thread");
				}
				mLedControlThread = new LedControlThread(msgSendHandler);
				mLedControlThread.setDaemon(true);
				mLedControlThread.mState = STATE_ERR1;
				mLedControlThread.start();
				break;
			default:
				break;
			}			
			//msgSendHandler.sendMessage(retMsg);
		}		
	};
	
	Handler msgSendHandler;
		
	int testVal = 0;
	
	LedManageThread(Handler handler)
	{
		msgSendHandler = handler;
	}

	@Override
	public void run(){
		
		Looper.prepare();	
		Looper.loop();
		
		/*while(true)
		{
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			testVal++;
			Log.i("Test", "TestVal " + testVal);			
		}*/		
	}
}