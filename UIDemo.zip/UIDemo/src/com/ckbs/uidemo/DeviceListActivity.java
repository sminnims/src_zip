package com.ckbs.uidemo;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class DeviceListActivity extends Activity {

	//private static JmDNS zeroConf = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_device_list);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.device_list, menu);
		return true;
	}

}
