package com.ckbs.uidemo;

import java.io.IOException;
import java.util.regex.Pattern;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ManualSearchActivity extends Activity {
	private static final String TAG = "ManualSearchActivity";
	static TextView deviceName;
	static ProgressDialog findDialog;
	Button okBtn, findBtn;
	EditText ipInputBox;
	String ipAddr = "";
	static String snmpDeviceName = "";
	static String t1 = "Device Name";
	static String snmpDeviceIP = "";
	snmpControlThread snmpThread;
	SnmpManager mSnmpManager;
	
	private SocketListener mSocketListener;
	
	public static final int SNMP_CMD_GET_DEVICE_NAME = 0;
	public static final int SNMP_CMD_GET_DEVICE_IP = 1;
	public static final int SNMP_CMD_GET_DEVICE_STATUS = 2;
	
	public static final int MSG_SNMP_CMD_SUCCESS = 3;
	public static final int MSG_SNMP_CMD_NO_RESPONSE = 4;
	

    @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_manual_search);
			
		okBtn = (Button)findViewById(R.id.okBtn);
		findBtn = (Button)findViewById(R.id.findBtn);
		
		okBtn.setOnClickListener(btnListener);
		findBtn.setOnClickListener(btnListener);
		
		ipInputBox = (EditText)findViewById(R.id.ipInputBox);
		deviceName = (TextView)findViewById(R.id.deviceName);
		
		mSnmpManager = new SnmpManager(mHandler);
		
		okBtn.setClickable(false);
		okBtn.setEnabled(false);
		
		ipInputBox.setFilters(new InputFilter[] {filterIP});		
		SnmpManager.setIP("");

	}
    
    public InputFilter filterIP = new InputFilter() {
		
		@Override
		public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
			Pattern ps = Pattern.compile("^[0-9.]+$");
			if(!ps.matcher(source).matches()) {
				return "";
			}
			return null;
		}

	};

	private OnClickListener btnListener = new OnClickListener(){
    	@Override
		public void onClick(View v){
    		switch(v.getId()){
    		case R.id.findBtn:
    			InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(ipInputBox.getWindowToken(), 0);
    			// dialog 스레드 만들어서 잠깐 돌리고, textView 내용을 기기명으로 변경.
    			ipAddr = ipInputBox.getText().toString();
    			
				SnmpManager.setIP(ipAddr);			
    			
    			findDialog = ProgressDialog.show(ManualSearchActivity.this, "Process",
    													getString(R.string.scan_process), true);
    			snmpThread = new snmpControlThread(mHandler);
    			snmpThread.start();
    			break;
    		case R.id.okBtn:
    			/*
    			 * Disable until find device
    			 */
    			//test

    			//test
    			
    			SocketManager.setIP(ipAddr);
    			
    			Intent mIntent = new Intent(ManualSearchActivity.this, MainActivity.class);
    			startActivity(mIntent);    			
    			finish();

    			break;
    		default:
    			break;
    				
    		}
    	}
    };

    public class snmpControlThread extends Thread {
    	
    	Handler mHandler;
    	Message msg;
    	
    	snmpControlThread(Handler h)
    	{
    		mHandler = h;
    	}

    		public void run(){
    			
    			snmpDeviceName  = SnmpManager.snmpGet(SNMP_CMD_GET_DEVICE_NAME);
    			if(snmpDeviceName.equals(""))
    			{	
    				findDialog.dismiss();
    				this.interrupt();
    			}
    			if(!this.interrupted())
    			{
    				snmpDeviceIP  = SnmpManager.snmpGet(SNMP_CMD_GET_DEVICE_IP);
    				findDialog.dismiss();
    			}
    			
    		}
    	
    	
    }

	public Handler mHandler  = new Handler(){
		
		@Override
		public void handleMessage(Message msg){
			switch(msg.what)
			{
			case MSG_SNMP_CMD_SUCCESS:
				deviceName.setText(snmpDeviceName.trim());
				okBtn.setClickable(true);	
				okBtn.setEnabled(true);
				
				break;
				
			case MSG_SNMP_CMD_NO_RESPONSE:
				snmpDeviceName = "";
				snmpDeviceIP = "";
				deviceName.setText(getString(R.string.device_name));
				okBtn.setClickable(false);	
				okBtn.setEnabled(false);
				Toast.makeText(ManualSearchActivity.this, getString(R.string.snmp_device_search_fail_alert), Toast.LENGTH_SHORT).show();
				break;
			default:
					break;
			}
		}
	};
}
