package com.ckbs.uidemo;

import android.util.Log;

public class CopySet {
	// 40bytes
	// copy set base setting
	private int count;
	private int density;
	private int sharpness;
	private int imageQuality;
	private int duplex;
	private int zoom; // x% * 10
	private int nup;
	private int cstPaperSize;
	private int collate;
	private int paperSize;
	
	public final static int ATTR_COUNT = 0;
	public final static int ATTR_DENSITY = 1;
	public final static int ATTR_SHARP = 2;
	public final static int ATTR_QUALITY = 4;
	public final static int ATTR_DUPLEX = 5;
	public final static int ATTR_ZOOM = 6;
	public final static int ATTR_NUP = 7;
	public final static int ATTR_CST = 8;
	public final static int ATTR_COLLATE = 9;
	public final static int ATTR_PAPER = 10;
	
	public CopySet() {
		init();
	}
	
	private void init() {
		count = 1;
		density = 4;
		sharpness = 3;
		imageQuality = 3;
		duplex = 0;
		zoom = 1000;
		nup = 0;
		cstPaperSize = 4;
		collate = 0;
		paperSize = 4;
	}
	
	public void setAttr(int ident, int val)
	{
		switch(ident)
		{
		case ATTR_COUNT:
			count = val;
			break;
		case ATTR_DENSITY:
			density = val;
			break;
		case ATTR_SHARP:
			sharpness = val;
			break;
		case ATTR_QUALITY:
			imageQuality = val;
			break;
		case ATTR_DUPLEX:
			duplex = val;
			break;
		case ATTR_ZOOM:
			zoom = val*10;
			break;
		case ATTR_NUP:
			nup = val;
			break;
		case ATTR_CST:
			cstPaperSize = val;
			break;
		case ATTR_COLLATE:
			collate = val;			
			break;
		case ATTR_PAPER:
			paperSize = val;
			break;
		default:
				break;			
		}
	}
	
	public void getAttr(byte[] dest) {
		
		if(dest.length < 40)
		{
			Log.e("ERR", "Wrong buffer size");
			return;
		}
			
        System.arraycopy(DataControl.int2byte(count), 			0, dest, 0,  4);
        System.arraycopy(DataControl.int2byte(density), 		0, dest, 4,  4);
        System.arraycopy(DataControl.int2byte(sharpness),		0, dest, 8,  4);
        System.arraycopy(DataControl.int2byte(imageQuality),	0, dest, 12,  4);
        System.arraycopy(DataControl.int2byte(duplex), 			0, dest, 16,  4);
        System.arraycopy(DataControl.int2byte(zoom), 			0, dest, 20,  4);
        System.arraycopy(DataControl.int2byte(nup), 			0, dest, 24,  4);
        System.arraycopy(DataControl.int2byte(cstPaperSize),	0, dest, 28,  4);
        System.arraycopy(DataControl.int2byte(collate), 		0, dest, 32,  4);
        System.arraycopy(DataControl.int2byte(paperSize),		0, dest, 36,  4);
		
	}
	
}
