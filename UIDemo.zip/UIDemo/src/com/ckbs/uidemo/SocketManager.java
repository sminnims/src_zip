package com.ckbs.uidemo;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import android.util.Log;

public class SocketManager {
	
	private final static String TAG = "SocketManager";

	public static String IP = "";
	
	public static int PORT = 7602;//7602;
	
	private static Socket socket;
	
	public static void setIP(String IPAddr)
	{
		IP = "";		
		IP = IPAddr.trim();
		Log.i(TAG, "Socket IP Set to " + IP);
	}
	
	public static Socket getSocket() throws IOException
	{
		if(socket == null)
		{
			Log.i("LOG", "Make new socket");
			socket = new Socket();
		}
		if(!socket.isConnected())
		{
			Log.i("LOG", IP +"/"+ PORT);
			
			socket.connect(new InetSocketAddress(IP, PORT));
			
			Log.i("SOCKET", socket.toString());
		}
		return socket;		
	}
	
	public static void closeSocket() throws IOException
	{
		if(socket != null)
		{
			socket.close();		
			socket = null;
		}
	}
	
	public static void sendMsg(byte[] msg) throws IOException
	{
		
		getSocket().getOutputStream().write(msg);
	}
}
