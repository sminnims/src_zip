package com.ckbs.uidemo;

public class DeviceListItem {

	String deviceName, deviceAddr;
	
	DeviceListItem(String mDeviceName, String mDeviceAddr)
	{
		deviceName = mDeviceName;
		deviceAddr = mDeviceAddr;
	}
}
