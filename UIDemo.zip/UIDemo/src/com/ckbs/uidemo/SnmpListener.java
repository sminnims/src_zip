package com.ckbs.uidemo;

import android.content.Context;
import android.os.Handler;


public class SnmpListener extends Thread{
	
	Handler mHandler;
	Context context;
	
	public SnmpListener (Context c, Handler h)
	{
		this.mHandler = h;
		this.context = c;		
	}
	
	@Override
	public void run(){
		super.run();
		
		while(true)
		{
			
		}
	}
}
