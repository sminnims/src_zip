package com.ckbs.uidemo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class DeviceSelectActivity extends Activity {
	
	private static boolean executedFlags;
	
	SimpleAdapter simpleAdapter;
	HashMap<String, String> deviceItem;
	ArrayList<HashMap<String,String>> deviceList = new ArrayList<HashMap<String, String>>();
	
	Intent mIntent;
	
	Button rescanBtn, manualSearchBtn;
	
	ProgressDialog rescanDialog;
    
	View v1;
	
	Handler handler = new Handler();
	@Override
	protected void onDestroy() {
		super.onDestroy();
		try {
			SocketManager.closeSocket();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void onPause() {
		super.onPause();
		executedFlags = true;
	}
	@Override
	protected void onResume() {
		super.onResume();
		
		if(executedFlags)
		{
			rescanDevice();	
		}
	}
	
    @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_device_select);
				
		executedFlags = false;
		
		ListView deviceListView = (ListView)findViewById(R.id.deviceListView);
		
		simpleAdapter = new SimpleAdapter(this, SnmpManager.deviceList, R.layout.device_list_item,
				new String[] {"device", "ip"}, new int[] {android.R.id.text1, android.R.id.text2});

		deviceListView.setAdapter(simpleAdapter);
		deviceListView.setOnItemClickListener(itemClickListener);
		

		rescanBtn = (Button)findViewById(R.id.rescanBtn);
		manualSearchBtn = (Button)findViewById(R.id.manualSearchBtn);
		
		rescanBtn.setOnClickListener(btnListener);
		manualSearchBtn.setOnClickListener(btnListener);
		
		v1 = findViewById(R.id.linearLayout1);		

    }
    /*
	@Override
	protected void onPause() {
		SnmpManager.deviceList.clear();
	}
	
	@Override
	protected void onResume() {
		SnmpManager.deviceList.clear();
	}
	
	@Override
	protected void onDestroy() {
		SnmpManager.deviceList.clear();
	}
     */
    private void rescanDevice() {
    	
		rescanDialog = ProgressDialog.show(DeviceSelectActivity.this, "Process",
				getString(R.string.search_process), true);
		SnmpManager.deviceList.clear();		
		
		new Thread(new Runnable(){
		@Override
			public void run(){  
			SnmpManager.findSnmpDevice(); 
			rescanDialog.dismiss();
			
			handler.post(new Runnable() {
				public void run() {
					simpleAdapter.notifyDataSetChanged();
				}
			});
		
			}
		}).start();	
    }
	private OnClickListener btnListener = new OnClickListener(){
    	@Override
		public void onClick(View v){
    		switch(v.getId()){
    		case R.id.rescanBtn:
    			// dialog    , device_list .  dialog.
    			rescanDevice();
    			break;
    		case R.id.manualSearchBtn:
    			mIntent = new Intent(DeviceSelectActivity.this, ManualSearchActivity.class);
    			startActivity(mIntent);    			
    			//  
    			//finish();
    			break;
    		default:
    			break;
    				
    		}
    	}
    };
    
    private OnItemClickListener itemClickListener = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			// TODO Auto-generated method stub
			//    
			HashMap<String,String> hm;
			String ip = "";
			ip = ((HashMap<String,String>) parent.getAdapter().getItem(position)).get("ip");
			Log.i("CHK", ip);
			SocketManager.setIP(ip);
			// LoginActivity - Socket Connect in onCreate
			mIntent = new Intent(DeviceSelectActivity.this, MainActivity.class);
			startActivity(mIntent);			
		}
		
	};

	@Override
	public void onBackPressed() {
		Builder d = new AlertDialog.Builder(this);
		d.setTitle(getString(R.string.app_name));
		d.setMessage(getString(R.string.exit_alert));
		d.setPositiveButton(getString(R.string.btn_msg_yes), new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				finish();
				
			}
		});
		d.setNegativeButton(getString(R.string.btn_msg_no), new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				dialog.cancel();
				
			}
		});
		
		d.show();
		
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.device_select, menu);
		return true;
	}

}
