package com.ckbs.uidemo;

public class DataControl {

	
    public static byte[] int2byte(int src) {
    	// change to little endian 
    	byte[] rtn = new byte[4];
    	rtn[3] = (byte)((src&0xFF000000)>>24);
    	rtn[2] = (byte)((src&0xFF0000)>>16);
    	rtn[1] = (byte)((src&0xFF00)>>8);
    	rtn[0] = (byte)(src&0xFF);    	    	
		return rtn;
    	
    }
    
   public static int byte2int(byte[] src) {
	   // change to big endian src:little endian
	   int i1 = src[3] & 0xFF;
	   int i2 = src[2] & 0xFF;
	   int i3 = src[1] & 0xFF;
	   int i4 = src[0] & 0xFF;
	   
	   return((i1 << 24) + (i2 << 16) + (i3 << 8) + (i4 << 0));
   }
    
    
    public static byte[] short2byte(int src) {
    	
    	byte[] rtn = new byte[2];
    	rtn[1] = (byte)((src&0xFF00)>>8);
    	rtn[0] = (byte)(src&0xFF);    	    	
		return rtn;
    	
    }
}
