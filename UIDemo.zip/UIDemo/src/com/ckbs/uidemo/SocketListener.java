package com.ckbs.uidemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class SocketListener extends Thread {
	
	private InputStream im;
	private BufferedReader br;
	
	Handler mHandler;
	
	Context context;
	
	public SocketListener(Context c, Handler h)
	{
		this.mHandler = h;
		this.context = c;
		
		try{
			im = SocketManager.getSocket().getInputStream();
			br = new BufferedReader(new InputStreamReader(im));
			
		} catch(IOException e) {
			Log.e("SocketListener", e.getMessage());
		}
	}
	
	@Override
	public void run(){
		super.run();
		
		while(!this.interrupted())
		{
			try{
				String rcvMsg;
				while((rcvMsg = br.readLine()) != null)
				{
					Log.i("SocketListener", rcvMsg);
					Message msg = Message.obtain(mHandler, 0,0,0, rcvMsg);
					mHandler.sendMessage(msg);	
					
					/*	
					tmpArr = new byte[4];
					System.arraycopy(cmdBuff, 0, tmpArr,  0,  4);
					rcvCmd.rcvIdent = new String(tmpArr);
					
					if(rcvCmd.rcvIdent.equals(refCmd))
					{					
						tmpArr = new byte[4];
						System.arraycopy(cmdBuff, 4, tmpArr,  0,  4);
						rcvCmd.rcvCmd = rcvCmd.getInt(tmpArr);
						
						tmpArr = new byte[4];
						System.arraycopy(cmdBuff, 8, tmpArr,  0,  4);
						rcvCmd.rcvOpt1 = rcvCmd.getInt(tmpArr);
						
						tmpArr = new byte[4];
						System.arraycopy(cmdBuff, 12, tmpArr,  0,  4);
						rcvCmd.rcvOpt2 = rcvCmd.getInt(tmpArr);
						
						Message msg = mHandler.obtainMessage(MainActivity.MSG_GET_MSG_FROM_SOCKET);
						mHandler.sendMessage(msg);					
					}
					else
					{
						Log.e("SocketListener[MsgErr]", "["+ rcvCmd.rcvIdent + "]" + " is wrong cmd");
					}		
				*/	
				}
			}catch(IOException e){
				Log.e("SocketListener", e.getMessage());
			}
		}
		/*
		 * Temp.
		 */
		try {
			SocketManager.closeSocket();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
