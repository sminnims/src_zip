package com.ckbs.uidemo;

import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

public class CopyMainActivity extends Activity {

	CopyCommand mCmd;
	SocketListener mSL;
	CopySet mCS;
	byte[] copySet;
	byte[] copyCmd;
	byte[] reqCmd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_copy_main);
		getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

		mSL = new SocketListener(getApplicationContext(), mHandler);
		mCmd = new CopyCommand();
		mCS = new CopySet();

		uMenu1 = findViewById(R.id.upperMenu1);
		uMenu2 = findViewById(R.id.upperMenu2);
		bMenu1 = findViewById(R.id.bottomMenu1);

		mainScreen = findViewById(R.id.mainScreen);

		printingScreen = findViewById(R.id.printingScreen);
		stopConfirmScreen = findViewById(R.id.stopConfirmScreen);
		stopScreen = findViewById(R.id.stopScreen);

		densityScreen = findViewById(R.id.densityScreen);
		originalTypeScreen = findViewById(R.id.originalTypeScreen);
		pageIntegrationScreen = findViewById(R.id.pageIntegrationScreen);
		copyRatioScreen = findViewById(R.id.copyRatioScreen);
		collateScreen = findViewById(R.id.collateScreen);
		duplexScreen = findViewById(R.id.duplexScreen);
		sharpnessScreen = findViewById(R.id.sharpnessScreen);

		upperMenuLayout = findViewById(R.id.upperMenuLayout);
		bottomMenuLayout = findViewById(R.id.bottomMenuLayout);

		startBtn = (ImageButton) findViewById(R.id.startBtn);
		copyModeBtn = (ImageButton) findViewById(R.id.copyB1tn);
		faxModeBtn = (ImageButton) findViewById(R.id.printBtn);
		scanModeBtn = (ImageButton) findViewById(R.id.faxBtn);

		densityLevelUpBtn = (ImageButton) findViewById(R.id.densityLevelUpBtn);
		densityLevelDownBtn = (ImageButton) findViewById(R.id.densityLevelDownBtn);
		sharpnessLevelUpBtn = (ImageButton) findViewById(R.id.sharpnessLevelUpBtn);
		sharpnessLevelDownBtn = (ImageButton) findViewById(R.id.sharpnessLevelDownBtn);

		startBtn.setOnClickListener(btnListener);
		copyModeBtn.setOnClickListener(btnListener);
		faxModeBtn.setOnClickListener(btnListener);
		scanModeBtn.setOnClickListener(btnListener);

		densityLevelUpBtn.setOnClickListener(btnListener);
		densityLevelDownBtn.setOnClickListener(btnListener);
		sharpnessLevelUpBtn.setOnClickListener(btnListener);
		sharpnessLevelDownBtn.setOnClickListener(btnListener);

		stopBtn = (Button) findViewById(R.id.stopBtn);
		closeBtn = (Button) findViewById(R.id.closeBtn);
		yesBtn = (Button) findViewById(R.id.yesBtn);
		noBtn = (Button) findViewById(R.id.noBtn);

		densityAutoBtn = (Button) findViewById(R.id.densityAutoBtn);
		densitySetBtn = (Button) findViewById(R.id.densitySetBtn);
		originalTypeSetBtn = (Button) findViewById(R.id.originalTypeSetBtn);
		pageIntegrationTypeSetBtn = (Button) findViewById(R.id.pageIntegrationTypeSetBtn);
		copyRatioSetBtn = (Button) findViewById(R.id.copyRatioSetBtn);
		collateOptionSetBtn = (Button) findViewById(R.id.collateOptionSetBtn);
		duplexOptionSetBtn = (Button) findViewById(R.id.duplexOptionSetBtn);
		sharpnessSetBtn = (Button) findViewById(R.id.sharpnessSetBtn);

		stopBtn.setOnClickListener(btnListener);
		closeBtn.setOnClickListener(btnListener);
		yesBtn.setOnClickListener(btnListener);
		noBtn.setOnClickListener(btnListener);

		densityAutoBtn.setOnClickListener(btnListener);
		densitySetBtn.setOnClickListener(btnListener);
		originalTypeSetBtn.setOnClickListener(btnListener);
		pageIntegrationTypeSetBtn.setOnClickListener(btnListener);
		copyRatioSetBtn.setOnClickListener(btnListener);
		collateOptionSetBtn.setOnClickListener(btnListener);
		duplexOptionSetBtn.setOnClickListener(btnListener);
		sharpnessSetBtn.setOnClickListener(btnListener);

		paperTypeInfo = (TextView) findViewById(R.id.paperType);
		copyRatioInfo = (TextView) findViewById(R.id.copyRatio);
		copyCounter = (exEditText) findViewById(R.id.copyCounter);
		copyRatioValue = (EditText) findViewById(R.id.copyRatioValue);

		copyCounter.setOnFocusChangeListener(fcListener);
		copyCounter.setOnClickListener(testListener);
		copyRatioValue.setOnFocusChangeListener(fcListener);
		copyRatioValue.setOnClickListener(testListener);

		copyCounter.setOnBackPressedHandler(mHandler);

		density = (TextView) findViewById(R.id.densityStatus);
		originalType = (TextView) findViewById(R.id.originalTypeStatus);
		copyRatio = (TextView) findViewById(R.id.copyRatioStatus);
		pageIntegration = (TextView) findViewById(R.id.pageIntegrationStatus);
		collateOption = (TextView) findViewById(R.id.collateStatus);
		duplexOption = (TextView) findViewById(R.id.duplexStatus);
		sharpness = (TextView) findViewById(R.id.sharpnessStatus);

		/*
		 * Device Information Display 초기화
		 */
		density.setText(getString(R.string.density_status) + " " + densityLevel);
		originalType.setText(getString(R.string.original_type_status)
				+ getString(R.string.original_type_text_and_photo_high_speed));
		copyRatio.setText(getString(R.string.copy_ratio_status) + " "
				+ copyRatioInfo.getText().toString() + "%");
		pageIntegration.setText(getString(R.string.page_integration_status)
				+ " " + getString(R.string.page_integration_off_option));
		collateOption.setText(getString(R.string.collate_option_status) + " "
				+ getString(R.string.collate_off_option));
		duplexOption.setText(getString(R.string.duplex_status) + " "
				+ getString(R.string.duplex_off_option));
		sharpness.setText(getString(R.string.sharpness_status) + " "
				+ sharpnessLevel);
		/*
		 * Device Information Display 초기화
		 */

		printing_msg_1 = (TextView) findViewById(R.id.PrintingMsg1);
		printing_msg_2 = (TextView) findViewById(R.id.PrintingMsg2);
		printing_msg_3 = (TextView) findViewById(R.id.PrintingMsg3);

		density.setOnClickListener(btnListener);
		originalType.setOnClickListener(btnListener);
		copyRatio.setOnClickListener(btnListener);
		pageIntegration.setOnClickListener(btnListener);
		collateOption.setOnClickListener(btnListener);
		duplexOption.setOnClickListener(btnListener);
		sharpness.setOnClickListener(btnListener);

		textRow = (TableRow) findViewById(R.id.textRow);
		text_photo_highRow = (TableRow) findViewById(R.id.textPhoto2Row);
		text_photoRow = (TableRow) findViewById(R.id.textPhoto1Row);
		photoRow = (TableRow) findViewById(R.id.photoRow);

		offOptionRow = (TableRow) findViewById(R.id.offOptionRow);
		twoInoneRow = (TableRow) findViewById(R.id.twoInoneRow);
		fourInoneRow = (TableRow) findViewById(R.id.fourInoneRow);
		idCardRow = (TableRow) findViewById(R.id.idCardRow);

		collateOnOptionRow = (TableRow) findViewById(R.id.collateOnOptionRow);
		collateOffOptionRow = (TableRow) findViewById(R.id.collateOffOptionRow);

		duplexOffOptionRow = (TableRow) findViewById(R.id.duplexOffOptionRow);
		duplex1to2OptionRow = (TableRow) findViewById(R.id.duplex1to2OptionRow);
		duplex2to1OptionRow = (TableRow) findViewById(R.id.duplex2to1OptionRow);
		duplex2to2OptionRow = (TableRow) findViewById(R.id.duplex2to2OptionRow);
		duplexLayoutOptionRow = (TableRow) findViewById(R.id.duplexLayoutOptionRow);

		textRow.setOnClickListener(rowClickListener);
		text_photo_highRow.setOnClickListener(rowClickListener);
		text_photoRow.setOnClickListener(rowClickListener);
		photoRow.setOnClickListener(rowClickListener);

		offOptionRow.setOnClickListener(rowClickListener);
		twoInoneRow.setOnClickListener(rowClickListener);
		fourInoneRow.setOnClickListener(rowClickListener);
		idCardRow.setOnClickListener(rowClickListener);

		collateOnOptionRow.setOnClickListener(rowClickListener);
		collateOffOptionRow.setOnClickListener(rowClickListener);

		duplexOffOptionRow.setOnClickListener(rowClickListener);
		duplex1to2OptionRow.setOnClickListener(rowClickListener);
		duplex2to1OptionRow.setOnClickListener(rowClickListener);
		duplex2to2OptionRow.setOnClickListener(rowClickListener);
		duplexLayoutOptionRow.setOnClickListener(rowClickListener);

		originalType1CheckBox = (CheckBox) findViewById(R.id.textTypeCheckBox);
		originalType2CheckBox = (CheckBox) findViewById(R.id.textPhotoType2CheckBox);
		originalType3CheckBox = (CheckBox) findViewById(R.id.textPhotoType1CheckBox);
		originalType4CheckBox = (CheckBox) findViewById(R.id.photoTypeCheckBox);

		integrationType1CheckBox = (CheckBox) findViewById(R.id.offOptionCheckBox);
		integrationType2CheckBox = (CheckBox) findViewById(R.id.twoInoneOptionCheckBox);
		integrationType3CheckBox = (CheckBox) findViewById(R.id.fourInoneOptionCheckBox);
		integrationType4CheckBox = (CheckBox) findViewById(R.id.idCardOptionCheckBox);

		collateOnCheckBox = (CheckBox) findViewById(R.id.collateOnCheckBox);
		collateOffCheckBox = (CheckBox) findViewById(R.id.collateOffCheckBox);

		duplexOffCheckBox = (CheckBox) findViewById(R.id.duplexOffCheckBox);
		duplex1to2CheckBox = (CheckBox) findViewById(R.id.duplex1to2CheckBox);
		duplex2to1CheckBox = (CheckBox) findViewById(R.id.duplex2to1CheckBox);
		duplex2to2CheckBox = (CheckBox) findViewById(R.id.duplex2to2CheckBox);
		duplexLayoutCheckBox = (CheckBox) findViewById(R.id.duplexLayoutCheckBox);

		densityLevelMeter = (ImageView) findViewById(R.id.densityLevelMeter);
		sharpnessLevelMeter = (ImageView) findViewById(R.id.sharpnessLevelMeter);

		greenLed = (ImageView) findViewById(R.id.greenLed);
		redLed = (ImageView) findViewById(R.id.redLed);

		greenLed.setEnabled(false);
		redLed.setEnabled(false);

		mLedManagerThread = new LedManageThread(mHandler);
		mLedManagerThread.setDaemon(true);
		mLedManagerThread.start();
		deviceStatusMsg = mLedManagerThread.msgGetHandler
				.obtainMessage(MainActivity.MSG_DEVICE_CONNECTED);
		mLedManagerThread.msgGetHandler.sendMessage(deviceStatusMsg);

		/*
		 * test code
		 */
		ckbsLogo = (ImageView) findViewById(R.id.ckbsLogo);
		ckbsLogo.setOnClickListener(testListener);
		redLed.setOnClickListener(testListener);
		errScreen = findViewById(R.id.errScreen);
		errImg = (ImageView) findViewById(R.id.errImg);
		errImg.setOnClickListener(testListener);
		coverScreen = findViewById(R.id.invisibleScreen);
		coverScreen.setOnClickListener(testListener);
		coverScreen.setVisibility(View.GONE);
		/*
		 * test code
		 */

		copyCounter.setImeOptions(EditorInfo.IME_ACTION_DONE);
		copyCounter
				.setOnEditorActionListener(new EditText.OnEditorActionListener() {

					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {

						switch (actionId) {
						case EditorInfo.IME_ACTION_DONE:
							setCopyCounter();
							break;
						}

						return false;
					}
				});

		copyRatioValue.setImeOptions(EditorInfo.IME_ACTION_DONE);
		copyRatioValue
				.setOnEditorActionListener(new EditText.OnEditorActionListener() {

					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {

						switch (actionId) {
						case EditorInfo.IME_ACTION_DONE:
							if(copyRatioValue.length() == 0)
								copyRatioValue.setText("25");
							Log.i("Focus", "EditText");
							break;
						}
						return false;
					}

				});

	}// end onCreate()

	private OnClickListener btnListener = new OnClickListener() {

		@Override
		public void onClick(View v) {

			uMenu1.setVisibility(View.GONE);
			uMenu2.setVisibility(View.GONE);
			bMenu1.setVisibility(View.GONE);
			mainScreen.setVisibility(View.GONE);
			printingScreen.setVisibility(View.GONE);
			stopConfirmScreen.setVisibility(View.GONE);
			stopScreen.setVisibility(View.GONE);

			densityScreen.setVisibility(View.GONE);
			originalTypeScreen.setVisibility(View.GONE);
			pageIntegrationScreen.setVisibility(View.GONE);
			copyRatioScreen.setVisibility(View.GONE);
			collateScreen.setVisibility(View.GONE);
			duplexScreen.setVisibility(View.GONE);
			sharpnessScreen.setVisibility(View.GONE);

			upperMenuLayout.setVisibility(View.GONE);
			bottomMenuLayout.setVisibility(View.GONE);

			// TODO Auto-generated method stub

			switch (v.getId()) {
			case R.id.copyB1tn:
				upperMenuLayout.setVisibility(View.VISIBLE);
				bottomMenuLayout.setVisibility(View.VISIBLE);
				uMenu1.setVisibility(View.VISIBLE);
				mainScreen.setVisibility(View.VISIBLE);
				bMenu1.setVisibility(View.VISIBLE);
				break;

			case R.id.startBtn:
				deviceStatusMsg = mLedManagerThread.msgGetHandler
						.obtainMessage(MainActivity.MSG_DEVICE_PRINTING);
				mLedManagerThread.msgGetHandler.sendMessage(deviceStatusMsg);
				printing_msg_1.setText(getString(R.string.printing_msg_1) + " "
						+ copyCounter.getText().toString() + " x 01");
				printing_msg_2.setText(getString(R.string.printing_msg_2) + " "
						+ copyRatioInfo.getText().toString() + "%");
				printing_msg_3.setText(getString(R.string.printing_msg_3) + " "
						+ paperTypeInfo.getText().toString());
				printingScreen.setVisibility(View.VISIBLE);
				reqCmd = new byte[60];
				copyCmd = new byte[20];
				copySet = new byte[40];
				System.arraycopy(
						DataControl.int2byte(mCmd.getCmd(mCmd.CMD_IDENT)), 0,
						reqCmd, 4, 4);
				System.arraycopy(
						DataControl.int2byte(mCmd.getCmd(mCmd.CMD_CMD)), 0,
						reqCmd, 8, 4);
				System.arraycopy(
						DataControl.int2byte(mCmd.getCmd(mCmd.CMD_OPT1)), 0,
						reqCmd, 12, 4);
				System.arraycopy(
						DataControl.int2byte(mCmd.getCmd(mCmd.CMD_OPT2)), 0,
						reqCmd, 16, 4);
				mCS.getAttr(copySet);
				System.arraycopy(copySet, 0, reqCmd, 20, 40);
				try {
					SocketManager.sendMsg(reqCmd);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				/*
				 * print thread 시작 thread는 기기에서 완료신호가 올때까지 돌다가 완료신호가 오면 화면
				 * 변경(초기화면)메세지를 핸들러로 전달
				 */
				break;

			case R.id.faxBtn:
				/*
				 * Temp Connected Test
				 */
				deviceStatusMsg = mLedManagerThread.msgGetHandler
						.obtainMessage(MainActivity.MSG_DEVICE_CONNECTED);
				mLedManagerThread.msgGetHandler.sendMessage(deviceStatusMsg);

				// mIntent = new Intent(CopyMainActivity.this,
				// ScanMainActivity.class);
				// startActivity(mIntent);
				break;

			case R.id.scanBtn:

				mIntent = new Intent(CopyMainActivity.this,
						ScanMainActivity.class);
				startActivity(mIntent);
				// copy activity 죽이기
				// 출력중에 스캔으로 이동하면?!@#!@#
				break;

			case R.id.printBtn:
				/*
				 * Temp Err1 State Test
				 */
				deviceStatusMsg = mLedManagerThread.msgGetHandler
						.obtainMessage(MainActivity.MSG_DEVICE_ERR1);
				mLedManagerThread.msgGetHandler.sendMessage(deviceStatusMsg);

				// mIntent = new Intent(CopyMainActivity.this,
				// FaxMainActivity.class);
				// startActivity(mIntent);
				break;

			case R.id.densityLevelUpBtn:
				if (densityLevel < 4) {
					densityLevel = densityLevel + 1;
				}
				changeLevelMeter(densityLevelMeter, densityLevel);
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				densityScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.densityLevelDownBtn:
				if (densityLevel > -4) {
					densityLevel = densityLevel - 1;
				}
				changeLevelMeter(densityLevelMeter, densityLevel);
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				densityScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.sharpnessLevelUpBtn:
				if (sharpnessLevel < 3) {
					sharpnessLevel = sharpnessLevel + 1;
				}
				changeLevelMeter(sharpnessLevelMeter, sharpnessLevel);
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				sharpnessScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.sharpnessLevelDownBtn:
				if (sharpnessLevel > -3) {
					sharpnessLevel = sharpnessLevel - 1;
				}
				changeLevelMeter(sharpnessLevelMeter, sharpnessLevel);
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				sharpnessScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.closeBtn:
				upperMenuLayout.setVisibility(View.VISIBLE);
				bottomMenuLayout.setVisibility(View.VISIBLE);
				uMenu1.setVisibility(View.VISIBLE);
				mainScreen.setVisibility(View.VISIBLE);
				bMenu1.setVisibility(View.VISIBLE);
				break;

			case R.id.stopBtn:
				// stopConfirmScreen.setVisibility(View.VISIBLE);
				/*
				 * Temp code
				 */
				Toast.makeText(CopyMainActivity.this, "No Function now",
						Toast.LENGTH_SHORT).show();
				upperMenuLayout.setVisibility(View.VISIBLE);
				bottomMenuLayout.setVisibility(View.VISIBLE);
				uMenu1.setVisibility(View.VISIBLE);
				mainScreen.setVisibility(View.VISIBLE);
				bMenu1.setVisibility(View.VISIBLE);
				break;

			case R.id.yesBtn:
				/*
				 * 디바이스에 중지신호 전달, 응답을 기다리는 스레드 응답이 오면 중지시키고 핸들러로 초기화면 메세지 던지기
				 */
				stopScreen.setVisibility(View.VISIBLE);

				/*
				 * LED Signal : 인쇄 취소중 // 빠른 깜빡임
				 */
				deviceStatusMsg = mLedManagerThread.msgGetHandler
						.obtainMessage(MainActivity.MSG_DEVICE_CONNECTING);
				mLedManagerThread.msgGetHandler.sendMessage(deviceStatusMsg);

				stopDialog = ProgressDialog.show(CopyMainActivity.this,
						"Process", getString(R.string.stop_process), true);

				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							Thread.sleep(3000);
						} catch (Exception e) {
						}
						stopDialog.dismiss();
						Message msg = mHandler
								.obtainMessage(MainActivity.MSG_STOP_DONE);
						mHandler.sendMessage(msg);

						/*
						 * LED Signal : 다이얼로그 종료 후 Connected상태로.
						 */
						deviceStatusMsg = mLedManagerThread.msgGetHandler
								.obtainMessage(MainActivity.MSG_DEVICE_CONNECTED);
						mLedManagerThread.msgGetHandler
								.sendMessage(deviceStatusMsg);

					}
				}).start();

				break;

			case R.id.noBtn:
				printingScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.densityAutoBtn:
				upperMenuLayout.setVisibility(View.VISIBLE);
				bottomMenuLayout.setVisibility(View.VISIBLE);
				uMenu1.setVisibility(View.VISIBLE);
				mainScreen.setVisibility(View.VISIBLE);
				bMenu1.setVisibility(View.VISIBLE);
				break;

			case R.id.densitySetBtn:
				if (densityLevel > 0) {
					density.setText(getString(R.string.density_status) + " +"
							+ densityLevel);
				} else {
					density.setText(getString(R.string.density_status) + " "
							+ densityLevel);
				}

				mCS.setAttr(mCS.ATTR_DENSITY, densityLevel + 4);
				upperMenuLayout.setVisibility(View.VISIBLE);
				bottomMenuLayout.setVisibility(View.VISIBLE);
				uMenu1.setVisibility(View.VISIBLE);
				mainScreen.setVisibility(View.VISIBLE);
				bMenu1.setVisibility(View.VISIBLE);
				break;

			case R.id.originalTypeSetBtn:
				if (originalType1CheckBox.isChecked()) {
					originalType
							.setText(getString(R.string.original_type_status)
									+ " "
									+ getString(R.string.original_type_text));
					mCS.setAttr(mCS.ATTR_QUALITY, 0);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (originalType2CheckBox.isChecked()) {
					originalType
							.setText(getString(R.string.original_type_status)
									+ " "
									+ getString(R.string.original_type_text_and_photo_high_speed));
					mCS.setAttr(mCS.ATTR_QUALITY, 3);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (originalType3CheckBox.isChecked()) {
					originalType
							.setText(getString(R.string.original_type_status)
									+ " "
									+ getString(R.string.original_type_text_and_photo));
					mCS.setAttr(mCS.ATTR_QUALITY, 1);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (originalType4CheckBox.isChecked()) {
					originalType
							.setText(getString(R.string.original_type_status)
									+ " "
									+ getString(R.string.original_type_photo));
					mCS.setAttr(mCS.ATTR_QUALITY, 2);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else {
					upperMenuLayout.setVisibility(View.VISIBLE);
					uMenu2.setVisibility(View.VISIBLE);
					originalTypeScreen.setVisibility(View.VISIBLE);
					Toast.makeText(CopyMainActivity.this,
							getString(R.string.select_copy_type_alert),
							Toast.LENGTH_SHORT).show();
				}
				break;

			case R.id.pageIntegrationTypeSetBtn:
				if (integrationType1CheckBox.isChecked()) {
					pageIntegration
							.setText(getString(R.string.page_integration_status)
									+ " "
									+ getString(R.string.page_integration_off_option));
					mCS.setAttr(mCS.ATTR_NUP, 0);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (integrationType2CheckBox.isChecked()) {
					pageIntegration
							.setText(getString(R.string.page_integration_status)
									+ " "
									+ getString(R.string.page_integration_2in1_option));
					mCS.setAttr(mCS.ATTR_NUP, 2);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (integrationType3CheckBox.isChecked()) {
					pageIntegration
							.setText(getString(R.string.page_integration_status)
									+ " "
									+ getString(R.string.page_integration_4in1_option));
					mCS.setAttr(mCS.ATTR_NUP, 4);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (integrationType4CheckBox.isChecked()) {
					pageIntegration
							.setText(getString(R.string.page_integration_status)
									+ " "
									+ getString(R.string.page_integration_IDCard_option));
					mCS.setAttr(mCS.ATTR_NUP, 5);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else {
					upperMenuLayout.setVisibility(View.VISIBLE);
					uMenu2.setVisibility(View.VISIBLE);
					pageIntegrationScreen.setVisibility(View.VISIBLE);
					Toast.makeText(CopyMainActivity.this,
							getString(R.string.select_integration_type_alert),
							Toast.LENGTH_SHORT).show();
				}
				break;

			case R.id.copyRatioSetBtn:
				/*
				 * 입력값 범위 체크 해야함. 25~400
				 */
				int mValue = 0;
				if (!copyRatioValue.getText().toString().equals("")
						&& copyRatioValue != null) {
					mValue = Integer.parseInt(copyRatioValue.getText()
							.toString());

					if (mValue >= 25 && mValue <= 400) {
						mCS.setAttr(mCS.ATTR_ZOOM, mValue);
						copyRatioInfo.setText(copyRatioValue.getText()
								.toString());
						copyRatio.setText(getString(R.string.copy_ratio_status)
								+ " " + copyRatioValue.getText().toString()
								+ "%");
						InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
						imm.hideSoftInputFromWindow(
								copyRatioValue.getWindowToken(), 0);
						upperMenuLayout.setVisibility(View.VISIBLE);
						bottomMenuLayout.setVisibility(View.VISIBLE);
						uMenu1.setVisibility(View.VISIBLE);
						mainScreen.setVisibility(View.VISIBLE);
						bMenu1.setVisibility(View.VISIBLE);
					} else {
						upperMenuLayout.setVisibility(View.VISIBLE);
						uMenu2.setVisibility(View.VISIBLE);
						copyRatioScreen.setVisibility(View.VISIBLE);
						Toast.makeText(
								CopyMainActivity.this,
								getString(R.string.invalid_copy_ratio_value_alert),
								Toast.LENGTH_SHORT).show();
					}
				} else {
					upperMenuLayout.setVisibility(View.VISIBLE);
					uMenu2.setVisibility(View.VISIBLE);
					copyRatioScreen.setVisibility(View.VISIBLE);
					Toast.makeText(CopyMainActivity.this,
							getString(R.string.invalid_copy_ratio_value_alert),
							Toast.LENGTH_SHORT).show();
				}
				break;

			case R.id.collateOptionSetBtn:
				if (collateOnCheckBox.isChecked()) {
					collateOption
							.setText(getString(R.string.collate_option_status)
									+ " "
									+ getString(R.string.collate_on_option));
					mCS.setAttr(mCS.ATTR_COLLATE, 1);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (collateOffCheckBox.isChecked()) {
					collateOption
							.setText(getString(R.string.collate_option_status)
									+ " "
									+ getString(R.string.collate_off_option));
					mCS.setAttr(mCS.ATTR_COLLATE, 0);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else {
					upperMenuLayout.setVisibility(View.VISIBLE);
					uMenu2.setVisibility(View.VISIBLE);
					collateScreen.setVisibility(View.VISIBLE);
					Toast.makeText(CopyMainActivity.this,
							getString(R.string.select_collate_option_alert),
							Toast.LENGTH_SHORT).show();
				}
				break;

			case R.id.duplexOptionSetBtn:
				if (duplexOffCheckBox.isChecked()) {
					duplexOption.setText(getString(R.string.duplex_status)
							+ " " + getString(R.string.duplex_off_option));
					mCS.setAttr(mCS.ATTR_DUPLEX, 0);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (duplex1to2CheckBox.isChecked()) {
					duplexOption.setText(getString(R.string.duplex_status)
							+ " " + getString(R.string.duplex_1to2_option));
					mCS.setAttr(mCS.ATTR_DUPLEX, 1);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (duplex2to1CheckBox.isChecked()) {
					duplexOption.setText(getString(R.string.duplex_status)
							+ " " + getString(R.string.duplex_2to1_option));
					mCS.setAttr(mCS.ATTR_DUPLEX, 2);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (duplex2to2CheckBox.isChecked()) {
					duplexOption.setText(getString(R.string.duplex_status)
							+ " " + getString(R.string.duplex_2to2_option));
					mCS.setAttr(mCS.ATTR_DUPLEX, 3);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else if (duplexLayoutCheckBox.isChecked()) {
					duplexOption.setText(getString(R.string.duplex_status)
							+ " " + getString(R.string.duplex_layout_option));
					mCS.setAttr(mCS.ATTR_DUPLEX, 4);
					upperMenuLayout.setVisibility(View.VISIBLE);
					bottomMenuLayout.setVisibility(View.VISIBLE);
					uMenu1.setVisibility(View.VISIBLE);
					mainScreen.setVisibility(View.VISIBLE);
					bMenu1.setVisibility(View.VISIBLE);
				} else {
					upperMenuLayout.setVisibility(View.VISIBLE);
					uMenu2.setVisibility(View.VISIBLE);
					duplexScreen.setVisibility(View.VISIBLE);
					Toast.makeText(CopyMainActivity.this,
							getString(R.string.select_duplex_option_alert),
							Toast.LENGTH_SHORT).show();
				}
				break;

			case R.id.sharpnessSetBtn:
				if (sharpnessLevel > 0) {
					sharpness.setText(getString(R.string.sharpness_status)
							+ " +" + sharpnessLevel);
				} else {
					sharpness.setText(getString(R.string.sharpness_status)
							+ " " + sharpnessLevel);
				}
				mCS.setAttr(mCS.ATTR_SHARP, sharpnessLevel + 3);
				upperMenuLayout.setVisibility(View.VISIBLE);
				bottomMenuLayout.setVisibility(View.VISIBLE);
				uMenu1.setVisibility(View.VISIBLE);
				mainScreen.setVisibility(View.VISIBLE);
				bMenu1.setVisibility(View.VISIBLE);
				break;

			case R.id.densityStatus:
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				densityScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.originalTypeStatus:
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				originalTypeScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.copyRatioStatus:
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				copyRatioValue.setText(copyRatioInfo.getText().toString());
				copyRatioValue.selectAll();
				copyRatioScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.pageIntegrationStatus:
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				pageIntegrationScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.collateStatus:
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				collateScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.duplexStatus:
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				duplexScreen.setVisibility(View.VISIBLE);
				break;

			case R.id.sharpnessStatus:
				upperMenuLayout.setVisibility(View.VISIBLE);
				uMenu2.setVisibility(View.VISIBLE);
				sharpnessScreen.setVisibility(View.VISIBLE);

			default:
				break;

			}

		}

	};
	/*
	 * test var
	 */
	ImageView ckbsLogo, errImg;

	// EditText copyCounter, copyRatioValue;
	EditText copyRatioValue;
	exEditText copyCounter;
	TextView copyRatioInfo, paperTypeInfo, density, originalType, copyRatio,
			pageIntegration, collateOption, duplexOption, sharpness,
			printing_msg_1, printing_msg_2, printing_msg_3;
	int densityLevel, sharpnessLevel = 0;
	ImageView densityLevelMeter, sharpnessLevelMeter, greenLed, redLed;
	Message deviceStatusMsg;
	View errScreen, coverScreen;
	private OnFocusChangeListener fcListener = new OnFocusChangeListener() {

		@Override
		public void onFocusChange(View v, boolean hasFocus) {
			// TODO Auto-generated method stub

			Log.i("Focus", "OnFocusChangeListener");
			((EditText) v).selectAll();

		}

	};
	final Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MainActivity.MSG_STOP_DONE:
				upperMenuLayout.setVisibility(View.VISIBLE);
				bottomMenuLayout.setVisibility(View.VISIBLE);
				stopScreen.setVisibility(View.INVISIBLE);
				uMenu1.setVisibility(View.VISIBLE);
				mainScreen.setVisibility(View.VISIBLE);
				bMenu1.setVisibility(View.VISIBLE);
				break;

			case MainActivity.MSG_GREEN_LED_ON:
				greenLed.setEnabled(true);
				break;

			case MainActivity.MSG_GREEN_LED_OFF:
				greenLed.setEnabled(false);
				break;

			case MainActivity.MSG_RED_LED_ON:
				redLed.setEnabled(true);
				break;

			case MainActivity.MSG_RED_LED_OFF:
				redLed.setEnabled(false);
				break;

			case MainActivity.ON_KEYBOARD_BACK_PROC:
				setCopyCounter();
				break;

			default:
				break;
			}
		}

	};

	Intent mIntent;

	LedManageThread mLedManagerThread;

	CheckBox originalType1CheckBox, originalType2CheckBox,
			originalType3CheckBox, originalType4CheckBox,
			integrationType1CheckBox, integrationType2CheckBox,
			integrationType3CheckBox, integrationType4CheckBox,
			collateOnCheckBox, collateOffCheckBox, duplexOffCheckBox,
			duplex1to2CheckBox, duplex2to1CheckBox, duplex2to2CheckBox,
			duplexLayoutCheckBox;

	private OnClickListener rowClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			/*
//			 * originalType1CheckBox.setChecked(false);
//			 * originalType2CheckBox.setChecked(false);
//			 * originalType3CheckBox.setChecked(false);
//			 * originalType4CheckBox.setChecked(false);
			 * 
			 * integrationType1CheckBox.setChecked(false);
			 * integrationType2CheckBox.setChecked(false);
			 * integrationType3CheckBox.setChecked(false);
			 * integrationType4CheckBox.setChecked(false);
			 * 
			 * collateOnCheckBox.setChecked(false);
			 * collateOffCheckBox.setChecked(false);
			 * 
			 * duplexOffCheckBox.setChecked(false);
			 */

			switch (v.getId()) {
			case R.id.textRow:
				originalType1CheckBox.setChecked(true);
				originalType2CheckBox.setChecked(false);
				originalType3CheckBox.setChecked(false);
				originalType4CheckBox.setChecked(false);
				break;

			case R.id.textPhoto2Row:
				originalType1CheckBox.setChecked(false);
				originalType2CheckBox.setChecked(true);
				originalType3CheckBox.setChecked(false);
				originalType4CheckBox.setChecked(false);
				break;

			case R.id.textPhoto1Row:
				originalType1CheckBox.setChecked(false);
				originalType2CheckBox.setChecked(false);
				originalType3CheckBox.setChecked(true);
				originalType4CheckBox.setChecked(false);
				break;

			case R.id.photoRow:
				originalType1CheckBox.setChecked(false);
				originalType2CheckBox.setChecked(false);
				originalType3CheckBox.setChecked(false);
				originalType4CheckBox.setChecked(true);
				break;

			case R.id.offOptionRow:
				 integrationType1CheckBox.setChecked(true);
				 integrationType2CheckBox.setChecked(false);
				 integrationType3CheckBox.setChecked(false);
				 integrationType4CheckBox.setChecked(false);
				break;

			case R.id.twoInoneRow:
				 integrationType1CheckBox.setChecked(false);
				 integrationType2CheckBox.setChecked(true);
				 integrationType3CheckBox.setChecked(false);
				 integrationType4CheckBox.setChecked(false);
				break;

			case R.id.fourInoneRow:
				 integrationType1CheckBox.setChecked(false);
				 integrationType2CheckBox.setChecked(false);
				 integrationType3CheckBox.setChecked(true);
				 integrationType4CheckBox.setChecked(false);
				break;

			case R.id.idCardRow:
				 integrationType1CheckBox.setChecked(false);
				 integrationType2CheckBox.setChecked(false);
				 integrationType3CheckBox.setChecked(false);
				 integrationType4CheckBox.setChecked(true);
				break;

			case R.id.collateOnOptionRow:
				collateOnCheckBox.setChecked(true);
				collateOffCheckBox.setChecked(false);
				break;

			case R.id.collateOffOptionRow:
				collateOffCheckBox.setChecked(true);
				collateOnCheckBox.setChecked(false);
				break;

			case R.id.duplexOffOptionRow:
				duplexOffCheckBox.setChecked(true);
				duplex1to2CheckBox.setChecked(false);
				duplex2to1CheckBox.setChecked(false);
				duplex2to2CheckBox.setChecked(false);
				duplexLayoutCheckBox.setChecked(false);
				break;

			case R.id.duplex1to2OptionRow:
				duplexOffCheckBox.setChecked(false);
				duplex1to2CheckBox.setChecked(true);
				duplex2to1CheckBox.setChecked(false);
				duplex2to2CheckBox.setChecked(false);
				duplexLayoutCheckBox.setChecked(false);
				break;

			case R.id.duplex2to1OptionRow:
				duplexOffCheckBox.setChecked(false);
				duplex1to2CheckBox.setChecked(false);
				duplex2to1CheckBox.setChecked(true);
				duplex2to2CheckBox.setChecked(false);
				duplexLayoutCheckBox.setChecked(false);
				break;

			case R.id.duplex2to2OptionRow:
				duplexOffCheckBox.setChecked(false);
				duplex1to2CheckBox.setChecked(false);
				duplex2to1CheckBox.setChecked(false);
				duplex2to2CheckBox.setChecked(true);
				duplexLayoutCheckBox.setChecked(false);
				break;

			case R.id.duplexLayoutOptionRow:
				duplexOffCheckBox.setChecked(false);
				duplex1to2CheckBox.setChecked(false);
				duplex2to1CheckBox.setChecked(false);
				duplex2to2CheckBox.setChecked(false);
				duplexLayoutCheckBox.setChecked(true);
				break;

			default:
				break;

			}

		}

	};
	ImageButton startBtn, copyModeBtn, faxModeBtn, scanModeBtn,
			densityLevelUpBtn, densityLevelDownBtn, sharpnessLevelUpBtn,
			sharpnessLevelDownBtn;
	Button stopBtn, closeBtn, yesBtn, noBtn, densityAutoBtn, densitySetBtn,
			originalTypeSetBtn, pageIntegrationTypeSetBtn, copyRatioSetBtn,
			collateOptionSetBtn, duplexOptionSetBtn, sharpnessSetBtn;

	ProgressDialog stopDialog;

	Boolean test_state = true;

	private OnClickListener testListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.copyCounter:
				coverScreen.setVisibility(View.VISIBLE);
				copyCounter.selectAll();
				break;
			case R.id.copyRatioValue:
				copyRatioValue.selectAll();
				break;

			case R.id.ckbsLogo:
				if (test_state) {
					deviceStatusMsg = mLedManagerThread.msgGetHandler
							.obtainMessage(MainActivity.MSG_DEVICE_ERR1);
					mLedManagerThread.msgGetHandler
							.sendMessage(deviceStatusMsg);
					redLed.setClickable(true);
					/*
					 * STATE red Led Blinking Clickable, show err screen
					 */
					test_state = false;
				} else {
					deviceStatusMsg = mLedManagerThread.msgGetHandler
							.obtainMessage(MainActivity.MSG_DEVICE_CONNECTED);
					mLedManagerThread.msgGetHandler
							.sendMessage(deviceStatusMsg);
					test_state = true;
					redLed.setClickable(false);
				}
				break;
			case R.id.redLed:
				/*
				 * bug report. 한번에 갈때도 있는데 안갈때도 있음. 스레드 문제? 몰라~
				 */
				uMenu1.setVisibility(View.GONE);
				uMenu2.setVisibility(View.GONE);
				bMenu1.setVisibility(View.GONE);
				mainScreen.setVisibility(View.GONE);
				printingScreen.setVisibility(View.GONE);
				stopConfirmScreen.setVisibility(View.GONE);
				stopScreen.setVisibility(View.GONE);

				densityScreen.setVisibility(View.GONE);
				originalTypeScreen.setVisibility(View.GONE);
				pageIntegrationScreen.setVisibility(View.GONE);
				copyRatioScreen.setVisibility(View.GONE);
				collateScreen.setVisibility(View.GONE);
				duplexScreen.setVisibility(View.GONE);
				duplexScreen.setVisibility(View.GONE);
				sharpnessScreen.setVisibility(View.GONE);
				/*
				 * Err Screen Visibel setting
				 */
				errScreen.setVisibility(View.VISIBLE);
				break;
			case R.id.errImg:
				errScreen.setVisibility(View.GONE);
				uMenu1.setVisibility(View.VISIBLE);
				bMenu1.setVisibility(View.VISIBLE);
				mainScreen.setVisibility(View.VISIBLE);

				break;

			case R.id.invisibleScreen:
				//
				break;

			}
		}
	};

	TableRow textRow, text_photo_highRow, text_photoRow, photoRow,
			offOptionRow, twoInoneRow, fourInoneRow, idCardRow,
			collateOnOptionRow, collateOffOptionRow, duplexOffOptionRow,
			duplex1to2OptionRow, duplex2to1OptionRow, duplex2to2OptionRow,
			duplexLayoutOptionRow;

	View uMenu1, uMenu2, bMenu1, mainScreen, printingScreen, stopConfirmScreen,
			stopScreen, densityScreen, originalTypeScreen,
			pageIntegrationScreen, copyRatioScreen, collateScreen,
			duplexScreen, sharpnessScreen, upperMenuLayout, bottomMenuLayout;;

	private void changeLevelMeter(ImageView v, int level) {
		switch (level) {
		case 0:
			v.setImageResource(R.drawable.level_0);
			break;
		case 1:
			v.setImageResource(R.drawable.level_p1);
			break;
		case 2:
			v.setImageResource(R.drawable.level_p2);
			break;
		case 3:
			v.setImageResource(R.drawable.level_p3);
			break;
		case 4:
			v.setImageResource(R.drawable.level_p4);
			break;
		case -1:
			v.setImageResource(R.drawable.level_m1);
			break;
		case -2:
			v.setImageResource(R.drawable.level_m2);
			break;
		case -3:
			v.setImageResource(R.drawable.level_m3);
			break;
		case -4:
			v.setImageResource(R.drawable.level_m4);
			break;

		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		coverScreen.setVisibility(View.GONE);
	}
	
	protected void onPause() {
		super.onPause();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.copy_main, menu);
		return true;
	}

	private void setCopyCounter() {
		coverScreen.setVisibility(View.GONE);
		// coverScreen.setClickable(false);

		if (copyCounter.length() == 1) {
			copyCounter.setText("0" + copyCounter.getText().toString());
		} else if (copyCounter.length() == 0) {
			copyCounter.setText("01");
		}

		mCS.setAttr(mCS.ATTR_COUNT,
				Integer.parseInt(copyCounter.getText().toString()));

	}

}
