﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace USBController_Report_LECTURE
{
    public partial class memoryDump : Form
    {
        public memoryDump()
        {
            InitializeComponent();
        }
    }
}
