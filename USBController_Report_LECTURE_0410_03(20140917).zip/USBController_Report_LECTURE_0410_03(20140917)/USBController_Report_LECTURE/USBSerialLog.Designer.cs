﻿namespace USBController_Report_LECTURE
{
    partial class USBSerialLog
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(USBSerialLog));
            this.txt_main_log = new System.Windows.Forms.TextBox();
            this.setting = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lab_log = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lab_level = new System.Windows.Forms.Label();
            this.lab_task = new System.Windows.Forms.Label();
            this.lab_time = new System.Windows.Forms.Label();
            this.btn_log_start = new System.Windows.Forms.Button();
            this.btn_log_end = new System.Windows.Forms.Button();
            this.setting.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_main_log
            // 
            this.txt_main_log.Location = new System.Drawing.Point(6, 133);
            this.txt_main_log.Multiline = true;
            this.txt_main_log.Name = "txt_main_log";
            this.txt_main_log.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_main_log.Size = new System.Drawing.Size(477, 525);
            this.txt_main_log.TabIndex = 4;
            // 
            // setting
            // 
            this.setting.Controls.Add(this.button2);
            this.setting.Controls.Add(this.comboBox2);
            this.setting.Controls.Add(this.button1);
            this.setting.Controls.Add(this.lab_log);
            this.setting.Controls.Add(this.comboBox1);
            this.setting.Controls.Add(this.lab_level);
            this.setting.Controls.Add(this.lab_task);
            this.setting.Controls.Add(this.lab_time);
            this.setting.Controls.Add(this.btn_log_start);
            this.setting.Controls.Add(this.btn_log_end);
            this.setting.Cursor = System.Windows.Forms.Cursors.Default;
            this.setting.Location = new System.Drawing.Point(6, 3);
            this.setting.Name = "setting";
            this.setting.Size = new System.Drawing.Size(477, 124);
            this.setting.TabIndex = 3;
            this.setting.TabStop = false;
            this.setting.Text = "Setting";
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(360, 20);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 50);
            this.button2.TabIndex = 9;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "HIGH",
            "NOMAL",
            "LOW"});
            this.comboBox2.Location = new System.Drawing.Point(252, 95);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(95, 20);
            this.comboBox2.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(253, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 50);
            this.button1.TabIndex = 8;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lab_log
            // 
            this.lab_log.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_log.Location = new System.Drawing.Point(360, 74);
            this.lab_log.Name = "lab_log";
            this.lab_log.Size = new System.Drawing.Size(100, 41);
            this.lab_log.TabIndex = 6;
            this.lab_log.Text = "LOG";
            this.lab_log.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "PMR",
            "UPR"});
            this.comboBox1.Location = new System.Drawing.Point(135, 95);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(104, 20);
            this.comboBox1.TabIndex = 2;
            // 
            // lab_level
            // 
            this.lab_level.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_level.Location = new System.Drawing.Point(252, 73);
            this.lab_level.Name = "lab_level";
            this.lab_level.Size = new System.Drawing.Size(95, 22);
            this.lab_level.TabIndex = 5;
            this.lab_level.Text = "LEVEL";
            this.lab_level.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_task
            // 
            this.lab_task.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_task.Location = new System.Drawing.Point(135, 74);
            this.lab_task.Name = "lab_task";
            this.lab_task.Size = new System.Drawing.Size(104, 20);
            this.lab_task.TabIndex = 4;
            this.lab_task.Text = "TASK";
            this.lab_task.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_time
            // 
            this.lab_time.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_time.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lab_time.Location = new System.Drawing.Point(24, 73);
            this.lab_time.Name = "lab_time";
            this.lab_time.Size = new System.Drawing.Size(100, 42);
            this.lab_time.TabIndex = 3;
            this.lab_time.Text = "TIME";
            this.lab_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_log_start
            // 
            this.btn_log_start.Image = ((System.Drawing.Image)(resources.GetObject("btn_log_start.Image")));
            this.btn_log_start.Location = new System.Drawing.Point(24, 20);
            this.btn_log_start.Name = "btn_log_start";
            this.btn_log_start.Size = new System.Drawing.Size(100, 50);
            this.btn_log_start.TabIndex = 0;
            this.btn_log_start.UseVisualStyleBackColor = true;
            this.btn_log_start.Click += new System.EventHandler(this.btn_log_start_Click);
            // 
            // btn_log_end
            // 
            this.btn_log_end.Image = ((System.Drawing.Image)(resources.GetObject("btn_log_end.Image")));
            this.btn_log_end.Location = new System.Drawing.Point(139, 20);
            this.btn_log_end.Name = "btn_log_end";
            this.btn_log_end.Size = new System.Drawing.Size(100, 50);
            this.btn_log_end.TabIndex = 2;
            this.btn_log_end.UseVisualStyleBackColor = true;
            this.btn_log_end.Click += new System.EventHandler(this.btn_log_end_Click);
            // 
            // USBSerialLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 670);
            this.Controls.Add(this.txt_main_log);
            this.Controls.Add(this.setting);
            this.Name = "USBSerialLog";
            this.Text = "USB Serial";
            this.setting.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_main_log;
        private System.Windows.Forms.GroupBox setting;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lab_log;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lab_level;
        private System.Windows.Forms.Label lab_task;
        private System.Windows.Forms.Label lab_time;
        private System.Windows.Forms.Button btn_log_start;
        private System.Windows.Forms.Button btn_log_end;
    }
}