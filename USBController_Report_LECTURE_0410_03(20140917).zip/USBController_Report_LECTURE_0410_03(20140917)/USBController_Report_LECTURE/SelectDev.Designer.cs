﻿namespace USBController_Report_LECTURE
{
    partial class SelectDev
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelectDev));
            this.combUSBconnectDev = new System.Windows.Forms.ComboBox();
            this.btnDev = new System.Windows.Forms.Button();
            this.checkSelectUSBtest = new System.Windows.Forms.CheckBox();
            this.checkSelectUSBSerial = new System.Windows.Forms.CheckBox();
            this.btnUSBinfo = new System.Windows.Forms.Button();
            this.btnUSBrst = new System.Windows.Forms.Button();
            this.bmpcanonlogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.bmpcanonlogo)).BeginInit();
            this.SuspendLayout();
            // 
            // combUSBconnectDev
            // 
            this.combUSBconnectDev.FormattingEnabled = true;
            this.combUSBconnectDev.Location = new System.Drawing.Point(12, 44);
            this.combUSBconnectDev.Name = "combUSBconnectDev";
            this.combUSBconnectDev.Size = new System.Drawing.Size(244, 20);
            this.combUSBconnectDev.TabIndex = 1;
            this.combUSBconnectDev.SelectedIndexChanged += new System.EventHandler(this.combUSBconnectDev_SelectedIndexChanged);
            // 
            // btnDev
            // 
            this.btnDev.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDev.Image = ((System.Drawing.Image)(resources.GetObject("btnDev.Image")));
            this.btnDev.Location = new System.Drawing.Point(268, 156);
            this.btnDev.Name = "btnDev";
            this.btnDev.Size = new System.Drawing.Size(115, 52);
            this.btnDev.TabIndex = 2;
            this.btnDev.UseVisualStyleBackColor = true;
            this.btnDev.Click += new System.EventHandler(this.btnDev_Click);
            // 
            // checkSelectUSBtest
            // 
            this.checkSelectUSBtest.AutoSize = true;
            this.checkSelectUSBtest.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkSelectUSBtest.Location = new System.Drawing.Point(12, 87);
            this.checkSelectUSBtest.Name = "checkSelectUSBtest";
            this.checkSelectUSBtest.Size = new System.Drawing.Size(85, 16);
            this.checkSelectUSBtest.TabIndex = 9;
            this.checkSelectUSBtest.Text = "USB Test";
            this.checkSelectUSBtest.UseVisualStyleBackColor = true;
            this.checkSelectUSBtest.CheckedChanged += new System.EventHandler(this.checkSelectUSBtest_CheckedChanged);
            // 
            // checkSelectUSBSerial
            // 
            this.checkSelectUSBSerial.AutoSize = true;
            this.checkSelectUSBSerial.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkSelectUSBSerial.Location = new System.Drawing.Point(12, 121);
            this.checkSelectUSBSerial.Name = "checkSelectUSBSerial";
            this.checkSelectUSBSerial.Size = new System.Drawing.Size(94, 16);
            this.checkSelectUSBSerial.TabIndex = 10;
            this.checkSelectUSBSerial.Text = "USB Serial";
            this.checkSelectUSBSerial.UseVisualStyleBackColor = true;
            this.checkSelectUSBSerial.CheckedChanged += new System.EventHandler(this.checkSelectUSBSerial_CheckedChanged);
            // 
            // btnUSBinfo
            // 
            this.btnUSBinfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUSBinfo.Image = ((System.Drawing.Image)(resources.GetObject("btnUSBinfo.Image")));
            this.btnUSBinfo.Location = new System.Drawing.Point(268, 85);
            this.btnUSBinfo.Name = "btnUSBinfo";
            this.btnUSBinfo.Size = new System.Drawing.Size(115, 52);
            this.btnUSBinfo.TabIndex = 12;
            this.btnUSBinfo.UseVisualStyleBackColor = true;
            this.btnUSBinfo.Click += new System.EventHandler(this.btnUSBinfo_Click);
            // 
            // btnUSBrst
            // 
            this.btnUSBrst.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUSBrst.Image = ((System.Drawing.Image)(resources.GetObject("btnUSBrst.Image")));
            this.btnUSBrst.Location = new System.Drawing.Point(268, 12);
            this.btnUSBrst.Name = "btnUSBrst";
            this.btnUSBrst.Size = new System.Drawing.Size(115, 52);
            this.btnUSBrst.TabIndex = 13;
            this.btnUSBrst.UseVisualStyleBackColor = true;
            this.btnUSBrst.Click += new System.EventHandler(this.btnUSBrst_Click);
            // 
            // bmpcanonlogo
            // 
            this.bmpcanonlogo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.bmpcanonlogo.Image = ((System.Drawing.Image)(resources.GetObject("bmpcanonlogo.Image")));
            this.bmpcanonlogo.Location = new System.Drawing.Point(12, 158);
            this.bmpcanonlogo.Name = "bmpcanonlogo";
            this.bmpcanonlogo.Size = new System.Drawing.Size(153, 50);
            this.bmpcanonlogo.TabIndex = 14;
            this.bmpcanonlogo.TabStop = false;
            // 
            // SelectDev
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 223);
            this.Controls.Add(this.bmpcanonlogo);
            this.Controls.Add(this.btnUSBrst);
            this.Controls.Add(this.btnUSBinfo);
            this.Controls.Add(this.checkSelectUSBSerial);
            this.Controls.Add(this.checkSelectUSBtest);
            this.Controls.Add(this.btnDev);
            this.Controls.Add(this.combUSBconnectDev);
            this.MaximizeBox = false;
            this.Name = "SelectDev";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CoBra USB Tool";
            ((System.ComponentModel.ISupportInitialize)(this.bmpcanonlogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combUSBconnectDev;
        private System.Windows.Forms.Button btnDev;
        private System.Windows.Forms.CheckBox checkSelectUSBtest;
        private System.Windows.Forms.CheckBox checkSelectUSBSerial;
        private System.Windows.Forms.Button btnUSBinfo;
        private System.Windows.Forms.Button btnUSBrst;
        private System.Windows.Forms.PictureBox bmpcanonlogo;
    }
}