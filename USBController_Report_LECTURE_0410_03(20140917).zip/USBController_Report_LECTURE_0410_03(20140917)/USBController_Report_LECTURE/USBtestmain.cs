﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading;
  
namespace USBController_Report_LECTURE
{
    public partial class USBtestmain : Form
    {
        //SelectDev selectedUSB = new SelectDev();
        public USBcontroller usb_test = null;
        byte read_ep_val, write_ep_val;
        public int USBdevPID, USBdevVID;
        delegate void SetTextCallback(string Text);
        public Thread data_check_th;
        public bool img_jbig_type ;
        public byte[] usb_ori_data_buff = new Byte[40 * 1024 * 1024];
        public byte[] usb_cpr_data_buff = new Byte[40 * 1024 * 1024];
        public int firstDataFlag;

        public USBtestmain()
        {
            InitializeComponent();
            usb_test = new USBcontroller();
            data_check_th = new Thread(new ThreadStart(data_check_th_start));
            data_check_th.Start();
            img_jbig_type = true;
            
        }
        private void data_check_th_start()
        {
            do
            {

                Thread.Sleep(10);
            } while (true);

        }
#if FALSE
        private void btnOpenFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog pFileDlg = new OpenFileDialog();
            pFileDlg.Filter = "PRN Files(*.prn)|*.prn|All Files(*.*)|*.*";
            pFileDlg.Title = "전송할 파일을 선택하여 주세요.";
            if (pFileDlg.ShowDialog() == DialogResult.OK)
            {
                String strFullPathFile = pFileDlg.FileName;
                // ToDo
                usb_test.file_path = strFullPathFile;
                txtFileDirectory.Text = strFullPathFile;
            }
        }

        private void btnSendFile_Click(object sender, EventArgs e)
        {
            byte[] buffer;
            int buf_length;
            buffer = ReadFile(usb_test.file_path);
            buf_length = buffer.Length;
            usb_test.writeFileProcess(buffer, buf_length);
        }
#endif
        public byte[] ReadFile(string filePath)
        {
            byte[] buffer;
            FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            try
            {
                int length = (int)fileStream.Length;  // get file length
                buffer = new byte[length];            // create buffer
                int count;                            // actual number of bytes read
                int sum = 0;                          // total number of bytes read

                // read until Read method returns 0 (end of the stream has been reached)
                while ((count = fileStream.Read(buffer, sum, length - sum)) > 0)
                    sum += count;  // sum is a buffer offset for next reading
            }
            finally
            {
                fileStream.Close();
            }
            return buffer;
        }
#if FALSE
        private void btnSendData_Click(object sender, EventArgs e)
        {
            usb_test.writeStrProcess(txtInputData.Text);
        }
#endif
        public void Show_message_box(string str)
        {
            MessageBox.Show(str);
        }
        private void combWriteEP_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (combWriteEP.SelectedItem.ToString())
            {
                case "EP01": write_ep_val = 0x01; break;
                case "EP02": write_ep_val = 0x02; break;
                case "EP03": write_ep_val = 0x03; break;
                case "EP04": write_ep_val = 0x04; break;
                case "EP05": write_ep_val = 0x05; break;
                case "EP06": write_ep_val = 0x06; break;
                case "EP07": write_ep_val = 0x07; break;
                case "EP08": write_ep_val = 0x08; break;
                case "EP09": write_ep_val = 0x09; break;
                case "EP10": write_ep_val = 0x0A; break;
                case "EP11": write_ep_val = 0x0B; break;
                case "EP12": write_ep_val = 0x0C; break;
                case "EP13": write_ep_val = 0x0D; break;
                case "EP14": write_ep_val = 0x0E; break;
                case "EP15": write_ep_val = 0x0F; break;
            }
            usb_test.write_ep = write_ep_val;
        }
        private void combReadEP_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (combReadEP.SelectedItem.ToString())
            {
                case "EP01": read_ep_val = 0x81; break;
                case "EP02": read_ep_val = 0x82; break;
                case "EP03": read_ep_val = 0x83; break;
                case "EP04": read_ep_val = 0x84; break;
                case "EP05": read_ep_val = 0x85; break;
                case "EP06": read_ep_val = 0x86; break;
                case "EP07": read_ep_val = 0x87; break;
                case "EP08": read_ep_val = 0x88; break;
                case "EP09": read_ep_val = 0x89; break;
                case "EP10": read_ep_val = 0x8A; break;
                case "EP11": read_ep_val = 0x8B; break;
                case "EP12": read_ep_val = 0x8C; break;
                case "EP13": read_ep_val = 0x8D; break;
                case "EP14": read_ep_val = 0x8E; break;
                case "EP15": read_ep_val = 0x8F; break;
            }
            usb_test.read_ep = read_ep_val;
        }

        private void btnUSBsettingDone_Click(object sender, EventArgs e)
        {
            
            try
            {
                //usb_test.Disconnect();
            }
            finally
            {
                usb_test.Pub_VID = 0x04a9;
                usb_test.Pub_PID = 0x27a9;  //MF: 0x27a8    MM: 0x27a9
                usb_test.Connect(usb_test.Pub_VID, usb_test.Pub_PID, 1, 0, (byte)read_ep_val, (byte)write_ep_val);
            }
        }
        public void DataProcessing(string Text)
        {
            if (this.txtUSBlog.InvokeRequired)
            {
                SetTextCallback dp = new SetTextCallback(DataProcessing);
                this.Invoke(dp, new object[] { Text });
            }
            else
            {
                this.txtUSBlog.Text += (Text);
                /*this.txtUSBlog.Text += ("data length:");
                this.txtUSBlog.Text += Convert.ToString(length);
                this.txtUSBlog.Text += ("\r\n");*/
                this.txtUSBlog.SelectionStart = txtUSBlog.Text.Length;
                this.txtUSBlog.ScrollToCaret();
                this.txtUSBlog.Refresh();
            }

        }
        public void test_txt()
        {
            this.txtUSBlog.Text = "START\r\n";
        }
        
        public void output_txt(String s)
        {
            CheckForIllegalCrossThreadCalls = false;
            txtUSBlog.AppendText( s+ "\r\n\n");
        }

        private bool compare_image(byte[] ori_img, byte[] cpr_img, int size)
        {
            int i = 0;

            for (i = 0; i < size; i++)
            {
                if (ori_img[i] != cpr_img[i])
                {
                    //output_txt(i.ToString() + "/" + ori_img[i].ToString() + "/" + cpr_img[i].ToString());
                    cpr_img.Initialize();
                    return false;
                }
            }
            return true;
#if FALSE
            if (byte.Equals(ori_img, cpr_img))
            {

                return true;
            }
            else
            {
                return false;
            }
#endif
        }      

        public void save_jbig(string str,int len, int count)
        {
           // if (img_jbig_type == true)
            int page = count + 1;
            if(true)
            {
                FileStream fileStream = new FileStream(str, FileMode.OpenOrCreate, FileAccess.ReadWrite);

                fileStream.Write(usb_test.read_data, 0, len);

                if (count == 0)
                {
                    Array.Copy(usb_test.read_data, usb_ori_data_buff, len);
                    output_txt("Save the original data in buff...\r\n");
                }
                else
                {
                    Array.Copy(usb_test.read_data, usb_cpr_data_buff, len);

                    if (!compare_image(usb_ori_data_buff, usb_cpr_data_buff, len))// return false if not same data
                    {
                        //print err detect log
                        output_txt("##page : " + page.ToString() + " / NG");
                    }
                    else
                    {
                        //print success err detect log
                        output_txt("page : " + page.ToString() + " / ok");
                    }
                }
                fileStream.Close();
            }
            else
            {
                // width  18 19
                // height 22 23
                FileStream fileStream1 = new FileStream("d:\\tmp\\test1.bmp", FileMode.OpenOrCreate, FileAccess.ReadWrite);
                fileStream1.Write(usb_test.read_data, 0, 62);
                int width = (usb_test.read_data[18]) + (usb_test.read_data[19]<<4);
                int height= (usb_test.read_data[22]) + (usb_test.read_data[23]<<4);
                for (int i = 6774 - 1; i > 0; i--)
                {
                    for (int j = 0; j < 2360; j++)
                    {
                        fileStream1.WriteByte(usb_test.read_data[((i * 2360) + j) + 62]);
                        len++;
                    }
                }
                for (int i = 0; i < usb_test.read_length - len; i++)
                {
                    fileStream1.WriteByte(0);
                }
                fileStream1.Close();

            }
        }
        private void BtnBMPsavedone_Click(object sender, EventArgs e)
        {
            FileStream fileStream = new FileStream("c:\\tmp\\test.jbig", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            fileStream.Write(usb_test.read_data, 0, usb_test.read_length);
            fileStream.Close();
            /*
       FileStream fileStream = new FileStream("c:\\tmp\\test.bmp", FileMode.OpenOrCreate, FileAccess.ReadWrite);
       int len = 0;
       fileStream.Write(usb_test.read_data, 0, usb_test.read_length);

       fileStream.Close();
       

       FileStream fileStream1 = new FileStream("c:\\tmp\\test1.bmp", FileMode.OpenOrCreate, FileAccess.ReadWrite);
       fileStream1.Write(usb_test.read_data, 0, 62);
    
       for (int i = 6774-1; i > 0; i--)
       {
           for (int j = 0; j < 2360; j++)
           {
               fileStream1.WriteByte(usb_test.read_data[((i*2360)+j)+62]);
               len++;
           }
       }
       for (int i = 0; i < usb_test.read_length - len;i++ )
           fileStream1.WriteByte(0);
       fileStream1.Close();
       */
        }

        private void test_clear_Click(object sender, EventArgs e)
        {
            this.txtUSBlog.Clear();
            usb_test.read_length = 0;
        
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
 
        }   

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {


        }

        private void txtUSBlog_TextChanged(object sender, EventArgs e)
        {

        }
#if FALSE
        private void img_type_chg_Click(object sender, EventArgs e)
        {
            chk_jbig.Checked = !chk_jbig.Checked;
            chk_bmp.Checked = !chk_bmp.Checked;
            chk_jbig.Invalidate();
            chk_bmp.Invalidate();
            img_jbig_type = !img_jbig_type;
     
        }
#endif
        private void txtInputData_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void USBtestmain_Load(object sender, EventArgs e)
        {

        }

        private void DataBuffClrBtn_Click(object sender, EventArgs e)
        {
            usb_ori_data_clear();
        }

        private void usb_ori_data_clear()
        {
            if (usb_ori_data_buff.Length == 0)
            {
                output_txt("already clear.\r\n");
            }
            else
            {
                output_txt(usb_ori_data_buff.Length.ToString() + " bytes exsist....\r\nclear original data..\r\n");
                usb_ori_data_buff.Initialize();
                usb_test.filecnt = 0;
            }
        }
    }
}
