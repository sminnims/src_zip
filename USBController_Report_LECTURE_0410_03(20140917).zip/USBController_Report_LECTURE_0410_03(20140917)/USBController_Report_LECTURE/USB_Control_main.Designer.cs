﻿namespace USBController_Report_LECTURE
{
    partial class USB_Control_main
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_device_name = new System.Windows.Forms.Label();
            this.combSelectUSBtest = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lab_device_name
            // 
            this.lab_device_name.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_device_name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lab_device_name.Location = new System.Drawing.Point(12, 9);
            this.lab_device_name.Name = "lab_device_name";
            this.lab_device_name.Size = new System.Drawing.Size(399, 23);
            this.lab_device_name.TabIndex = 3;
            this.lab_device_name.Text = "device name";
            this.lab_device_name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // combSelectUSBtest
            // 
            this.combSelectUSBtest.FormattingEnabled = true;
            this.combSelectUSBtest.Items.AddRange(new object[] {
            "Do USB Test",
            "Do USB Serial",
            "See Device Information"});
            this.combSelectUSBtest.Location = new System.Drawing.Point(12, 47);
            this.combSelectUSBtest.Name = "combSelectUSBtest";
            this.combSelectUSBtest.Size = new System.Drawing.Size(399, 20);
            this.combSelectUSBtest.TabIndex = 7;
            this.combSelectUSBtest.SelectedIndexChanged += new System.EventHandler(this.combSelectUSBtest_SelectedIndexChanged);
            // 
            // USB_Control_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(420, 83);
            this.Controls.Add(this.combSelectUSBtest);
            this.Controls.Add(this.lab_device_name);
            this.Name = "USB_Control_main";
            this.Text = "USB_Controller";
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Label lab_device_name;
        private System.Windows.Forms.ComboBox combSelectUSBtest; //private label  -> public label modify
    }
}

