﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections.ObjectModel;


namespace USBController_Report_LECTURE
{
    public partial class SelectDev : Form
    {
        public USBcontroller usb_class_load = null;
        //USB_Control_main USBmain = new USB_Control_main();
        USBdeviceInfo usb_info = new USBdeviceInfo();
        USBtestmain usb_test_class = new USBtestmain();
        //USBSerialLog usb_serial = new USBSerialLog();
        string tmp_dev_name;

        public SelectDev()
        {
            InitializeComponent();
            usb_class_load = new USBcontroller();
            usb_test_class.usb_test = this.usb_class_load;
            this.usb_class_load = usb_test_class.usb_test;
            //usb_class_load.us
            usb_class_load.Connect_all_device_info(null, 0); // all of devices find 
            show_comb_box_usb_dev();
            usb_class_load.USB_handler_add();
            usb_class_load.usbmain = usb_test_class;
        }
        public void show_comb_box_usb_dev() // get device list
        {
            int str_index, last_index;
            bool end_flag = true;
            string tmp_str;

            combUSBconnectDev.Items.Add("Serial Mode");
            do
            {

                str_index = usb_class_load.usb_dev1_info.IndexOf("USBDEV");
                last_index = usb_class_load.usb_dev1_info.LastIndexOf("USBDEV");

                tmp_str = usb_class_load.usb_dev1_info.Remove(str_index, last_index - str_index + 6);
                usb_class_load.usb_dev1_info = usb_class_load.usb_dev1_info.Remove(0, str_index + 6);
                combUSBconnectDev.Items.Add(tmp_str);
                if(usb_class_load.usb_dev1_info.Length == 0) end_flag = false;

            } while (end_flag);
        }

        private void combUSBconnectDev_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnDev_Click(object sender, EventArgs e)
        {
            usb_test_class.test_txt();
            if (combUSBconnectDev.SelectedItem != null)
            {
                tmp_dev_name = combUSBconnectDev.SelectedItem.ToString(); // selected item get name
            }
            if (tmp_dev_name == null)
            {
                MessageBox.Show("잘못된 디바이스가 선택되었습니다. \n다시 선택해주세요");
                return;
            }
            //20120519 추가
            if (checkSelectUSBtest.Checked == false && checkSelectUSBSerial.Checked == false)
            {
                MessageBox.Show("Checkbox가 선택되지 않았습니다. \n다시 선택해주세요");
            }
            else
            {
                if (checkSelectUSBtest.Checked == true)
                {
                    tmp_dev_name = combUSBconnectDev.SelectedItem.ToString(); 
                    usb_class_load.Connect_all_device_info(tmp_dev_name, 1);
                    usb_test_class.Show();
                    this.Visible = false;
                }

                if (checkSelectUSBSerial.Checked == true)
                {
                    //usb_serial.Show();
                    MessageBox.Show("지원 하지 않는 기능 입니다");
                    //this.Visible = false;
                }
            }
        }

        private void btnUSBinfo_Click(object sender, EventArgs e)               //20120519 추가
        {
            if (combUSBconnectDev.SelectedItem != null)
            {
                tmp_dev_name = combUSBconnectDev.SelectedItem.ToString(); // selected item get name
            }

            if (tmp_dev_name == null)
            {
                MessageBox.Show("디바이스가 설정되지 않았습니다. \n다시 선택해주세요");
                return;
            }
            else
            {
                usb_info.lab_usb_all_info.Text = usb_class_load.usb_get_info(); // label에 정보 표시
                usb_info.Show();
            }
        }

        private void btnUSBrst_Click(object sender, EventArgs e)
        {
            InitializeComponent();
            usb_class_load = new USBcontroller();
            usb_test_class.usb_test = this.usb_class_load;
            this.usb_class_load = usb_test_class.usb_test;
            usb_class_load.Connect_all_device_info(null, 0);
            show_comb_box_usb_dev();
            usb_class_load.USB_handler_add();

            
        }

        private void checkSelectUSBtest_CheckedChanged(object sender, EventArgs e)          //20120519 추가
        {

        }

        private void checkSelectUSBSerial_CheckedChanged(object sender, EventArgs e)       //20120519 추가
        {

        }        
    }
}
