﻿namespace USBController_Report_LECTURE
{
    partial class USBtestmain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(USBtestmain));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtUSBlog = new System.Windows.Forms.TextBox();
            this.test_clear = new System.Windows.Forms.Button();
            this.DataBuffClrBtn = new System.Windows.Forms.Button();
            this.combWriteEP = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.combReadEP = new System.Windows.Forms.ComboBox();
            this.btnUSBsettingDone = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(436, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(154, 50);
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // txtUSBlog
            // 
            this.txtUSBlog.Location = new System.Drawing.Point(16, 131);
            this.txtUSBlog.Multiline = true;
            this.txtUSBlog.Name = "txtUSBlog";
            this.txtUSBlog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtUSBlog.Size = new System.Drawing.Size(578, 241);
            this.txtUSBlog.TabIndex = 4;
            this.txtUSBlog.TextChanged += new System.EventHandler(this.txtUSBlog_TextChanged);
            // 
            // test_clear
            // 
            this.test_clear.Location = new System.Drawing.Point(413, 378);
            this.test_clear.Name = "test_clear";
            this.test_clear.Size = new System.Drawing.Size(177, 49);
            this.test_clear.TabIndex = 31;
            this.test_clear.Text = "Log Clear";
            this.test_clear.UseVisualStyleBackColor = true;
            this.test_clear.Click += new System.EventHandler(this.test_clear_Click);
            // 
            // DataBuffClrBtn
            // 
            this.DataBuffClrBtn.Location = new System.Drawing.Point(219, 378);
            this.DataBuffClrBtn.Name = "DataBuffClrBtn";
            this.DataBuffClrBtn.Size = new System.Drawing.Size(177, 49);
            this.DataBuffClrBtn.TabIndex = 35;
            this.DataBuffClrBtn.Text = "Original Page Clear";
            this.DataBuffClrBtn.UseVisualStyleBackColor = true;
            this.DataBuffClrBtn.Click += new System.EventHandler(this.DataBuffClrBtn_Click);
            // 
            // combWriteEP
            // 
            this.combWriteEP.FormattingEnabled = true;
            this.combWriteEP.Items.AddRange(new object[] {
            "EP01",
            "EP02",
            "EP03",
            "EP04",
            "EP05",
            "EP06",
            "EP07",
            "EP08"});
            this.combWriteEP.Location = new System.Drawing.Point(6, 55);
            this.combWriteEP.Name = "combWriteEP";
            this.combWriteEP.Size = new System.Drawing.Size(68, 20);
            this.combWriteEP.TabIndex = 24;
            this.combWriteEP.SelectedIndexChanged += new System.EventHandler(this.combWriteEP_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Location = new System.Drawing.Point(6, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 28);
            this.label6.TabIndex = 22;
            this.label6.Text = "WriteEP";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Location = new System.Drawing.Point(80, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 28);
            this.label7.TabIndex = 23;
            this.label7.Text = "ReadEP";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // combReadEP
            // 
            this.combReadEP.FormattingEnabled = true;
            this.combReadEP.Items.AddRange(new object[] {
            "EP01",
            "EP02",
            "EP03",
            "EP04",
            "EP05",
            "EP06",
            "EP07",
            "EP08"});
            this.combReadEP.Location = new System.Drawing.Point(80, 54);
            this.combReadEP.Name = "combReadEP";
            this.combReadEP.Size = new System.Drawing.Size(68, 20);
            this.combReadEP.TabIndex = 25;
            this.combReadEP.SelectedIndexChanged += new System.EventHandler(this.combReadEP_SelectedIndexChanged);
            // 
            // btnUSBsettingDone
            // 
            this.btnUSBsettingDone.Image = ((System.Drawing.Image)(resources.GetObject("btnUSBsettingDone.Image")));
            this.btnUSBsettingDone.Location = new System.Drawing.Point(46, 77);
            this.btnUSBsettingDone.Name = "btnUSBsettingDone";
            this.btnUSBsettingDone.Size = new System.Drawing.Size(102, 29);
            this.btnUSBsettingDone.TabIndex = 7;
            this.btnUSBsettingDone.UseVisualStyleBackColor = true;
            this.btnUSBsettingDone.Click += new System.EventHandler(this.btnUSBsettingDone_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnUSBsettingDone);
            this.groupBox1.Controls.Add(this.combReadEP);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.combWriteEP);
            this.groupBox1.Location = new System.Drawing.Point(10, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(154, 112);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Endpoint Set";
            // 
            // USBtestmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 450);
            this.Controls.Add(this.DataBuffClrBtn);
            this.Controls.Add(this.test_clear);
            this.Controls.Add(this.txtUSBlog);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Name = "USBtestmain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "USB Test";
            this.Load += new System.EventHandler(this.USBtestmain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtUSBlog;
        private System.Windows.Forms.Button test_clear;
        private System.Windows.Forms.Button DataBuffClrBtn;
        private System.Windows.Forms.ComboBox combWriteEP;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox combReadEP;
        private System.Windows.Forms.Button btnUSBsettingDone;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}