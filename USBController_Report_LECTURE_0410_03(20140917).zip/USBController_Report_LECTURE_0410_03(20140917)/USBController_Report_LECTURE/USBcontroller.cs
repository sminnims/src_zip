﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LibUsbDotNet;
using LibUsbDotNet.DeviceNotify;
using LibUsbDotNet.WinUsb;
using LibUsbDotNet.Main;
using LibUsbDotNet.LudnMonoLibUsb;
using LibUsbDotNet.LibUsb;
using LibUsbDotNet.Descriptors;
using LibUsbDotNet.Info;
using System.Collections.ObjectModel;
using System.Runtime.InteropServices;


public enum USB_STATUS
{
    USB_OK = 0,
    USB_WAIT,
    USB_WRITE_FAIL,
    USB_READ_FAIL,
    USB_FAIL,
}


namespace USBController_Report_LECTURE
{
    public class USBcontroller
    {
        public IDeviceNotifier UsbDeviceNotifier = DeviceNotifier.OpenDeviceNotifier();
        public UsbEndpointReader usb_reader;
        public UsbEndpointWriter usb_writer;
        public UsbDevice MyUsbDevice;
        public UsbRegDeviceList allDevices = UsbDevice.AllDevices;
        public ReadEndpointID read_set_ep;
        public WriteEndpointID write_set_ep;
        public int Pub_VID;
        public int Pub_PID;
        public string usb_info_str;
        public string file_path;
        public string usb_dev1_info;
        public int show_usb_txt_info = 0;
        public byte read_ep, write_ep;
        public IntPtr read_buffer = new IntPtr();
        public byte[] read_data = new Byte[1024 * 1024 * 40];
        public int read_length;
        public USBtestmain usbmain;
        public int filecnt;
        public void Main(string[] args)
        {
            ErrorCode ec = ErrorCode.None;

            try
            {
                // Find and open the usb device.
                UsbDeviceFinder MyUsbFinder = new UsbDeviceFinder(Pub_VID, Pub_PID);

                // If the device is open and ready
                if (MyUsbDevice == null) throw new Exception("Device Not Found.");

                // If this is a "whole" usb device (libusb-win32, linux libusb-1.0)
                // it exposes an IUsbDevice interface. If not (WinUSB) the 
                // 'wholeUsbDevice' variable will be null indicating this is 
                // an interface of a device; it does not require or support 
                // configuration and interface selection.
                IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                if (!ReferenceEquals(wholeUsbDevice, null))
                {
                    // This is a "whole" USB device. Before it can be used, 
                    // the desired configuration and interface must be selected.

                    // Select config #1
                    wholeUsbDevice.SetConfiguration(1);

                    // Claim interface #0.
                    wholeUsbDevice.ClaimInterface(0);
                }

                // open read endpoint 1.
                UsbEndpointReader reader = MyUsbDevice.OpenEndpointReader(ReadEndpointID.Ep02);


                byte[] readBuffer = new byte[1024];
                while (ec == ErrorCode.None)
                {
                    int bytesRead;

                    // If the device hasn't sent data in the last 5 seconds,
                    // a timeout error (ec = IoTimedOut) will occur. 
                    ec = reader.Read(readBuffer, 5000, out bytesRead);

                    if (bytesRead == 0) throw new Exception(string.Format("{0}:No more bytes!", ec));
                    //Console.WriteLine("{0} bytes read", bytesRead);

                    // Write that output to the console.
                    //Console.Write(Encoding.Default.GetString(readBuffer, 0, bytesRead));
                }

                //Console.WriteLine("\r\nDone!\r\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine((ec != ErrorCode.None ? ec + ":" : String.Empty) + ex.Message);
            }
            finally
            {
                if (MyUsbDevice != null)
                {
                    if (MyUsbDevice.IsOpen)
                    {
                        // If this is a "whole" usb device (libusb-win32, linux libusb-1.0)
                        // it exposes an IUsbDevice interface. If not (WinUSB) the 
                        // 'wholeUsbDevice' variable will be null indicating this is 
                        // an interface of a device; it does not require or support 
                        // configuration and interface selection.
                        IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                        if (!ReferenceEquals(wholeUsbDevice, null))
                        {
                            // Release interface #0.
                            wholeUsbDevice.ReleaseInterface(0);
                        }

                        MyUsbDevice.Close();
                    }
                    MyUsbDevice = null;

                    // Free usb resources
                    UsbDevice.Exit();

                }

                // Wait for user input..
                //Console.ReadKey();
            }
        }

        //all usb device info get 
        public void Connect_all_device_info(string str, int mode)
        {
            foreach (UsbRegistry usbRegistry in allDevices)
            {
                if (mode == 0)
                {
                    if (usbRegistry.FullName != null)
                    {
                        UsbDeviceFinder MyUsbFinder = new UsbDeviceFinder(usbRegistry.Vid, usbRegistry.Pid);
                        MyUsbDevice = UsbDevice.OpenUsbDevice(MyUsbFinder);
                        //Pub_VID = usbRegistry.Device.UsbRegistryInfo.Vid;
                        //Pub_PID = usbRegistry.Device.UsbRegistryInfo.Pid;
                        usb_dev1_info += usbRegistry.FullName.ToString() + "USBDEV";
                    }
                }
                if (mode == 1) //selected device's VID, PID get
                {
                    if (usbRegistry.FullName == str)
                    {
                        UsbDeviceFinder MyUsbFinder = new UsbDeviceFinder(usbRegistry.Vid, usbRegistry.Pid);
                        MyUsbDevice = UsbDevice.OpenUsbDevice(MyUsbFinder);
                        Pub_VID = usbRegistry.Device.UsbRegistryInfo.Vid;
                        Pub_PID = usbRegistry.Device.UsbRegistryInfo.Pid;
                    }
                }
                if (usbRegistry.Open(out MyUsbDevice))
                {

                    usb_set_info(MyUsbDevice.Info.ToString());
                    for (int iConfig = 0; iConfig < MyUsbDevice.Configs.Count; iConfig++)
                    {
                        UsbConfigInfo configInfo = MyUsbDevice.Configs[iConfig];
                        usb_set_info(usb_get_info() + "\n" + "Config Information \n" + configInfo);//show config info

                        ReadOnlyCollection<UsbInterfaceInfo> interfaceList = configInfo.InterfaceInfoList;
                        for (int iInterface = 0; iInterface < interfaceList.Count; iInterface++)
                        {
                            UsbInterfaceInfo interfaceInfo = interfaceList[iInterface];
                            usb_set_info(usb_get_info() + "\n" + "Interface Information \n" + interfaceInfo);//show interface info 

                            ReadOnlyCollection<UsbEndpointInfo> endpointList = interfaceInfo.EndpointInfoList;
                            for (int iEndpoint = 0; iEndpoint < endpointList.Count; iEndpoint++)
                            {
                                usb_set_info(usb_get_info() + "\n" + "Endpoint Information \n" + endpointList[iEndpoint].ToString()); // show end point list 
                                //endpointList[iEndpoint].Descriptor.EndpointID;
                            }
                        }
                    }
                }
                
            }

            //Connect(0x04a9, 0x2773, 0, 1, (byte)ReadEndpointID.Ep02, (byte)WriteEndpointID.Ep01);
            show_usb_txt_info = 1;
           
            //Connect(Pub_VID, Pub_PID, 1, 0, (byte)ReadEndpointID.Ep02, (byte)WriteEndpointID.Ep01);

        }
        // string info 
        public void usb_set_info(string str)
        {
            usb_info_str = str;
        }
        public string usb_get_info()
        {
            return usb_info_str;
        }
        //read endpoint set
        private ReadEndpointID read_Endpoint_value_set(byte Rep)
        {
            switch(Rep)
            {
                case 0x81: read_set_ep = ReadEndpointID.Ep01; break;
                case 0x82: read_set_ep = ReadEndpointID.Ep02;; break;
                case 0x83: read_set_ep = ReadEndpointID.Ep03;; break;
                case 0x84: read_set_ep = ReadEndpointID.Ep04;; break;
                case 0x85: read_set_ep = ReadEndpointID.Ep05;; break;
                case 0x86: read_set_ep = ReadEndpointID.Ep06;; break;
                case 0x87: read_set_ep = ReadEndpointID.Ep07;; break;
                case 0x88: read_set_ep = ReadEndpointID.Ep08;; break;
                case 0x89: read_set_ep = ReadEndpointID.Ep09;; break;
                case 0x8A: read_set_ep = ReadEndpointID.Ep10;; break;
                case 0x8B: read_set_ep = ReadEndpointID.Ep11;; break;
                case 0x8C: read_set_ep = ReadEndpointID.Ep12;; break;
                case 0x8D: read_set_ep = ReadEndpointID.Ep13;; break;
                case 0x8E: read_set_ep = ReadEndpointID.Ep14;; break;
                case 0x8F: read_set_ep = ReadEndpointID.Ep15;; break;
            }
            return read_set_ep;
        }
        //write end point set
        private WriteEndpointID write_Endpoint_value_set(byte Wep)
        {
            switch (Wep)
            {
                case 0x81: write_set_ep = WriteEndpointID.Ep01; break;
                case 0x82: write_set_ep = WriteEndpointID.Ep02; ; break;
                case 0x83: write_set_ep = WriteEndpointID.Ep03; ; break;
                case 0x84: write_set_ep = WriteEndpointID.Ep04; ; break;
                case 0x85: write_set_ep = WriteEndpointID.Ep05; ; break;
                case 0x86: write_set_ep = WriteEndpointID.Ep06; ; break;
                case 0x87: write_set_ep = WriteEndpointID.Ep07; ; break;
                case 0x88: write_set_ep = WriteEndpointID.Ep08; ; break;
                case 0x89: write_set_ep = WriteEndpointID.Ep09; ; break;
                case 0x8A: write_set_ep = WriteEndpointID.Ep10; ; break;
                case 0x8B: write_set_ep = WriteEndpointID.Ep11; ; break;
                case 0x8C: write_set_ep = WriteEndpointID.Ep12; ; break;
                case 0x8D: write_set_ep = WriteEndpointID.Ep13; ; break;
                case 0x8E: write_set_ep = WriteEndpointID.Ep14; ; break;
                case 0x8F: write_set_ep = WriteEndpointID.Ep15; ; break;
            }
            return write_set_ep;
        }
        public USB_STATUS Connect(int VenderID, int ProductID, byte ConfID, int InterID, byte Rep, byte Wep)
        {

            Pub_VID = VenderID;
            Pub_PID = ProductID;

            UsbDeviceFinder MyUsbFinder = new UsbDeviceFinder(VenderID, ProductID);
            //UsbDeviceFinder MyUsbFinder = new UsbDeviceFinder(0x04a9, 0x2736); //A297
            ErrorCode ec = ErrorCode.None;

            try
            {

                //MyUsbDevice.AllDevices;
                MyUsbDevice = UsbDevice.OpenUsbDevice(MyUsbFinder);
                if(MyUsbDevice.IsOpen == false) MyUsbDevice.Close();

                //MyUsbDevice.GetConfiguration(out 0);

                if (MyUsbDevice == null) throw new Exception("Device Not Found.");

                //UsbEndpointReader reader = MyUsbDevice.OpenEndpointReader(ReadEndpointID.Ep02);

                //usb_reader = MyUsbDevice.OpenEndpointReader(ReadEndpointID.Ep02);
                //usb_writer = MyUsbDevice.OpenEndpointWriter(WriteEndpointID.Ep01);

                IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;

                if (!ReferenceEquals(wholeUsbDevice, null))
                {
                    wholeUsbDevice.SetConfiguration(1); 
                    wholeUsbDevice.ClaimInterface(0);
                    //wholeUsbDevice.SetConfiguration(1);
                    //wholeUsbDevice.ClaimInterface(0);
                }

                usb_reader = MyUsbDevice.OpenEndpointReader(ReadEndpointID.Ep02);
                usb_writer = MyUsbDevice.OpenEndpointWriter(WriteEndpointID.Ep05);

                //string cmdLine = regex.Replace(Environment.CommandLine, "^\".+?\"^.*? |^.*? ", "", RegexOptions.Singleline);

                ReadEventinitStart();
                return USB_STATUS.USB_OK;


            }
            catch (Exception ex)
            {
                return USB_STATUS.USB_FAIL;
            }

        }
        public void ReadEventinitStart()
        {
            usb_reader.DataReceivedEnabled = true;
            //usb_reader.d
            usb_reader.DataReceived += (ReadEvent);
        }
        public USB_STATUS writeFileProcess(byte[] buffer, int buf_len)
        {
            //string rec = send;
            Connect(Pub_VID, Pub_PID, 1, 0, read_ep, write_ep);
            //Connect(0x04a9, 0x2773, 1, 0, 2, 1); 
            UsbDeviceFinder MyUsbFinder = new UsbDeviceFinder(Pub_VID, Pub_PID);

            try
            {
                MyUsbDevice = UsbDevice.OpenUsbDevice(MyUsbFinder);

                ErrorCode ec = ErrorCode.None;
                int bytesWritten = 64;

                ec = usb_writer.Write(buffer, buf_len, out bytesWritten);


                if (ec != ErrorCode.None) throw new Exception(UsbDevice.LastErrorString);
                return USB_STATUS.USB_OK;
            }
            catch (System.Exception e)
            {
                return USB_STATUS.USB_WRITE_FAIL;
            }
            finally
            {
                if (MyUsbDevice != null)
                {
                    if (MyUsbDevice.IsOpen)
                    {
                        // If this is a "whole" usb device (libusb-win32, linux libusb-1.0)
                        // it exposes an IUsbDevice interface. If not (WinUSB) the 
                        // 'wholeUsbDevice' variable will be null indicating this is 
                        // an interface of a device; it does not require or support 
                        // configuration and interface selection.
                        IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                        if (!ReferenceEquals(wholeUsbDevice, null))
                        {
                            // Release interface #0.
                            wholeUsbDevice.ReleaseInterface(0);
                        }
                        MyUsbDevice.Close();
                    }
                }
                MyUsbDevice = null;

                // Free usb resources
                UsbDevice.Exit();

                // Wait for user input..
                //Console.ReadKey();
            }
        }
        public USB_STATUS writeStrProcess(string send)
        {
            string rec = send;
            UsbDeviceFinder MyUsbFinder = new UsbDeviceFinder(0x04a9, 0x2773);


            try
            {
                Connect(Pub_VID, Pub_PID, 1, 0, read_ep, write_ep);
                MyUsbDevice = UsbDevice.OpenUsbDevice(MyUsbFinder);

                ErrorCode ec = ErrorCode.None;
                int bytesWritten = send.Length;
                byte[] data = UnicodeEncoding.ASCII.GetBytes(send);
                //아스키코드 변환
                ec = usb_writer.Write(data, 2000, out bytesWritten);


                if (ec != ErrorCode.None) throw new Exception(UsbDevice.LastErrorString);
                return USB_STATUS.USB_OK;
            }
            catch (System.Exception e)
            {
                return USB_STATUS.USB_WRITE_FAIL;
            }
            finally
            {
                if (MyUsbDevice != null)
                {
                    if (MyUsbDevice.IsOpen)
                    {
                        // If this is a "whole" usb device (libusb-win32, linux libusb-1.0)
                        // it exposes an IUsbDevice interface. If not (WinUSB) the 
                        // 'wholeUsbDevice' variable will be null indicating this is 
                        // an interface of a device; it does not require or support 
                        // configuration and interface selection.
                        IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                        if (!ReferenceEquals(wholeUsbDevice, null))
                        {
                            // Release interface #0.
                            wholeUsbDevice.ReleaseInterface(0);
                        }
                        MyUsbDevice.Close();
                    }
                }
                MyUsbDevice = null;

                // Free usb resources
                UsbDevice.Exit();

                // Wait for user input..
                //Console.ReadKey();
            }
        }
        public USB_STATUS writeProcessEP0(byte reqtype, byte req, short val, short idx, string str)
        {
            //UsbSetupPacket packet = new UsbSetupPacket((byte)reqtype, (byte)req, (short)val, idx, len);
            int temp1;
            IntPtr buffer = new IntPtr();
            string tmp_txt;
            tmp_txt = str;
            byte[] data = UnicodeEncoding.ASCII.GetBytes(tmp_txt);

            UsbSetupPacket packet = new UsbSetupPacket((byte)reqtype, (byte)req, (short)val, idx, (short)data.Length);
        
            buffer = Marshal.AllocHGlobal(data.Length + 1);
            Marshal.Copy(data, 0, buffer, data.Length);
            Connect(Pub_VID, Pub_PID, 1, 0, read_ep, write_ep);
            UsbDeviceFinder MyUsbFinder = new UsbDeviceFinder(Pub_VID, Pub_PID);

            try
            {

                MyUsbDevice = UsbDevice.OpenUsbDevice(MyUsbFinder);
                MyUsbDevice.ControlTransfer(ref packet, buffer, data.Length, out temp1);

                return USB_STATUS.USB_OK;
            }
            catch (System.Exception e)
            {
                return USB_STATUS.USB_WRITE_FAIL;
            }
            finally
            {
                if (MyUsbDevice != null)
                {
                    if (MyUsbDevice.IsOpen)
                    {
                        // If this is a "whole" usb device (libusb-win32, linux libusb-1.0)
                        // it exposes an IUsbDevice interface. If not (WinUSB) the 
                        // 'wholeUsbDevice' variable will be null indicating this is 
                        // an interface of a device; it does not require or support 
                        // configuration and interface selection.
                        IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                        if (!ReferenceEquals(wholeUsbDevice, null))
                        {
                            // Release interface #0.
                            wholeUsbDevice.ReleaseInterface(0);
                        }
                        MyUsbDevice.Close();
                    }
                }
                MyUsbDevice = null;

                // Free usb resources
                UsbDevice.Exit();
            }

        }
        public void USB_handler_add()
        {
            UsbDeviceNotifier.OnDeviceNotify += OnDeviceNotifyEvent; //이벤트 핸들 추가!!
            read_buffer = Marshal.AllocHGlobal(1024*5);
            //ReadEventinitStart();
            //UsbDeviceNotifier.Enabled = true;
            //UsbDeviceNotifier.Enabled = false;
            //UsbDeviceNotifier.OnDeviceNotify -= OnDeviceNotifyEvent;
        }
        public void Disconnect()
        {
            try
            {
                if (MyUsbDevice != null)
                {
                    if (MyUsbDevice.IsOpen)
                    {
                        // If this is a "whole" usb device (libusb-win32, linux libusb-1.0)
                        // it exposes an IUsbDevice interface. If not (WinUSB) the 
                        // 'wholeUsbDevice' variable will be null indicating this is 
                        // an interface of a device; it does not require or support 
                        // configuration and interface selection.
                        IUsbDevice wholeUsbDevice = MyUsbDevice as IUsbDevice;
                        if (!ReferenceEquals(wholeUsbDevice, null))
                        {
                            // Release interface #0.
                            wholeUsbDevice.ReleaseInterface(0);
                        }
                        MyUsbDevice.Close();
                    }
                }
                MyUsbDevice = null;

                // Free usb resources
                UsbDevice.Exit();
            }
            finally
            {
            }
        }
        private void OnDeviceNotifyEvent(object sender, DeviceNotifyEventArgs e)
        {

            // 장치가 삽입되면 인식하여 이벤트가 발생한다
            try
            {
                Disconnect();
            }
            finally
            {
                Connect(Pub_VID, Pub_PID, 1, 0, read_ep, write_ep);
            }
           //Connect(0x066F, 0x5100, 1, 0, 2, 1); //253MB
          //Connect(0x04a9, 0x2736, 1, 0, 2, 1);  //A297
           // Connect(0x04a9, 0x2776, 1, 0, 2, 1); //253FA

        }
        public void ReadEvent(object sender, EndpointDataEventArgs e)
        {         
            //return;
            //USBtestmain usb_main = new USBtestmain();
            string str = UnicodeEncoding.ASCII.GetString(e.Buffer, 0, e.Count);
            //string txt_str;
            if (str.IndexOf("page end") != -1)
            {
                if (usbmain.img_jbig_type)
                {
                    str = "e:\\Work\\RL_Prj\\output\\output" + filecnt.ToString() + ".jbig";
                }
                else
                {
                    str = "e:\\Work\\RL_Prj\\output\\output" + filecnt.ToString() + ".bmp";
                }
                usbmain.save_jbig(str, read_length, filecnt);
                read_length = 0;
                filecnt++;
            }
            else
            {
                Marshal.Copy(e.Buffer, 0, read_buffer, e.Count);
                Marshal.Copy(read_buffer, read_data, read_length, e.Count);
                read_length += e.Count;
            }
        }
    }
}
