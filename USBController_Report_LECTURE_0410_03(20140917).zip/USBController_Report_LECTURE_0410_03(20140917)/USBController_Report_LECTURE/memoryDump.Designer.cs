﻿namespace USBController_Report_LECTURE
{
    partial class memoryDump
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.setting = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lab_level = new System.Windows.Forms.Label();
            this.lab_task = new System.Windows.Forms.Label();
            this.lab_time = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.setting.SuspendLayout();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(390, 359);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 31);
            this.button4.TabIndex = 17;
            this.button4.Text = "CLOSE";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(284, 359);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 31);
            this.button3.TabIndex = 16;
            this.button3.Text = "OK";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Location = new System.Drawing.Point(12, 137);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(476, 216);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Result";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(12, 21);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(446, 179);
            this.textBox4.TabIndex = 0;
            // 
            // setting
            // 
            this.setting.Controls.Add(this.textBox3);
            this.setting.Controls.Add(this.textBox2);
            this.setting.Controls.Add(this.textBox1);
            this.setting.Controls.Add(this.button2);
            this.setting.Controls.Add(this.button1);
            this.setting.Controls.Add(this.lab_level);
            this.setting.Controls.Add(this.lab_task);
            this.setting.Controls.Add(this.lab_time);
            this.setting.Cursor = System.Windows.Forms.Cursors.Default;
            this.setting.Location = new System.Drawing.Point(12, 12);
            this.setting.Name = "setting";
            this.setting.Size = new System.Drawing.Size(477, 107);
            this.setting.TabIndex = 14;
            this.setting.TabStop = false;
            this.setting.Text = "Setting";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(281, 68);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(72, 31);
            this.textBox3.TabIndex = 11;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(138, 69);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(72, 31);
            this.textBox2.TabIndex = 10;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(139, 26);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(214, 31);
            this.textBox1.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(359, 26);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 31);
            this.button2.TabIndex = 9;
            this.button2.Text = "Open";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(359, 68);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 31);
            this.button1.TabIndex = 8;
            this.button1.Text = "Send";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lab_level
            // 
            this.lab_level.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_level.Location = new System.Drawing.Point(216, 69);
            this.lab_level.Name = "lab_level";
            this.lab_level.Size = new System.Drawing.Size(57, 31);
            this.lab_level.TabIndex = 5;
            this.lab_level.Text = "SIZE";
            this.lab_level.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_task
            // 
            this.lab_task.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_task.Location = new System.Drawing.Point(20, 69);
            this.lab_task.Name = "lab_task";
            this.lab_task.Size = new System.Drawing.Size(113, 31);
            this.lab_task.TabIndex = 4;
            this.lab_task.Text = "ADDRESS";
            this.lab_task.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_time
            // 
            this.lab_time.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_time.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lab_time.Location = new System.Drawing.Point(20, 26);
            this.lab_time.Name = "lab_time";
            this.lab_time.Size = new System.Drawing.Size(113, 30);
            this.lab_time.TabIndex = 3;
            this.lab_time.Text = "SAVE FILE PATH";
            this.lab_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // memoryDump
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 402);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.setting);
            this.Name = "memoryDump";
            this.Text = "memoryDump";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.setting.ResumeLayout(false);
            this.setting.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox setting;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lab_level;
        private System.Windows.Forms.Label lab_task;
        private System.Windows.Forms.Label lab_time;
    }
}