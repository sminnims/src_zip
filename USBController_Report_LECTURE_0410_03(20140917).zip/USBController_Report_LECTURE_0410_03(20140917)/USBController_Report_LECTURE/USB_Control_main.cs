﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;


namespace USBController_Report_LECTURE
{
    public partial class USB_Control_main : Form
    {

        USBcontroller usb_class = new USBcontroller();
        USBdeviceInfo usb_info = new USBdeviceInfo();
        USBtestmain usb_test_class = new USBtestmain();
        USBSerialLog usb_serial = new USBSerialLog();
        public string usb_info_for_all; //get selected USB device all info 

        public USB_Control_main()
        {
            InitializeComponent();
            // 여기 USB 이벤트 핸들러 추가 
        }
        private void combSelectUSBtest_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (combSelectUSBtest.SelectedItem.ToString() == "Do USB Test")
            {
                usb_test_class.Show();
                this.Visible = false;
            }
            else if (combSelectUSBtest.SelectedItem.ToString() == "See Device Information")
            {
                usb_info.lab_usb_all_info.Text = usb_info_for_all; // label에 정보 표시
                if (usb_info.IsDisposed)
                {
                    usb_info = new USBdeviceInfo();
                    usb_info.lab_usb_all_info.Text = usb_info_for_all;
                }
                usb_info.Show();
            }
            else if(combSelectUSBtest.SelectedItem.ToString() == "Do USB Serial")
            {
                usb_serial.Show();
                this.Visible = false;
            }
        }
    }
}
