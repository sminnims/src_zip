#include "find_ks.h"

#include "maze_main.h"

int Mirro_algorithm(char const **arr, char road, char wall, int *x, int *y, int turn, int size)
{
	int i = 0;
	int j = 0;
	int k = 0;
	static int start_x_pos = 0;
	static char start_x_flag = 0;
	static char turn2_start_x_flag = 0;
	static char **local_map = NULL;
	static char origin_map_copy_flag = 0;
	char save = 0;
	int rtn = D_KEEP_GOING;

#if WANT_TO_INIT
	if (turn == 3)
	{
		start_x_pos = 0;
		start_x_flag = 0;
		turn2_start_x_flag = 0;
		origin_map_copy_flag = 0;
		free(local_map);
		return 0;
	}
#endif
#if TEST_CODE
	/* TEST : PRINT INIT BOARD */
	printf("ORIGIN_MAP\n");
#endif

	/* turn�� �ʱⰪ�� 0 or 1 ? */
	if (turn == 1 && origin_map_copy_flag == 0)
	{
		local_map = (char **)malloc(sizeof(char *) * size);
		if (local_map == NULL)
		{
			printf("[ERR] ALLOC ERR\n");
			system("pause");
			return -1;
		}
		for (k = 0; k < size; k++)
		{
			local_map[k] = (char*)malloc(sizeof(char) * size);
			if (local_map[k] == NULL)
			{
				printf("[ERR] ALLOC ERR\n");
				system("pause");
				return -1;
			}
		}

		/* COPY ORIFIN MAP TO SAVE MAP(LOCAL) */
		for (i = 0; i < size; i++)
		{
			for (j = 0; j < size; j++)
			{
				local_map[i][j] = arr[i][j];
				origin_map_copy_flag++;
			}
		}
	}


#if TEST_CODE
	/* TEST : PRINT SAVE BOARD */
	printf("\nlocal_map\n");
	for (i = 0; i < MAX_BOARD_SIZE; i++)
	{
		for (j = 0; j < MAX_BOARD_SIZE; j++)
		{
			printf("%d ", local_map[i][j]);
		}
		printf("\n");
	}
#endif

	/* FIND FIRST START POINT */
	if (start_x_flag == 0)
	{
		for (i = 0; i < size; i++)
		{
			if (local_map[0][i] == road)
			{
				start_x_pos = i;
				*x = start_x_pos;
				start_x_flag++;
				return D_KEEP_GOING;
			}
		}
	}

	/* FIND FIRST START POINT ( TRUN 2 )*/
	if (turn == 2 && turn2_start_x_flag == 0)
	{
		*x = start_x_pos;
		turn2_start_x_flag++;
		return D_KEEP_GOING;
	}

#if TEST_CODE
	printf(" start x pos : %d\n", start_x_pos);
#endif
	if (turn == 1)
	{
		for (int temp = 0; temp < 16; temp++)
		{
			/* PRIORITY1 : FIND ROAD */
			if (local_map[(*y) + 1][*x] == road + temp)
			{
				/* P1-1 : FIND BOTTOM */
				//(local_map[*y][*x])++;
				(local_map[*y][*x]) = (local_map[*y][*x]) + 1 + temp;
				(*y)++;
				rtn = D_KEEP_GOING;
				break;
			}
			else if (local_map[*y][(*x) + 1] == road + temp)
			{
				/* P1-2 : FIND RIGHT */
				(local_map[*y][*x]) = (local_map[*y][*x]) + 1 + temp;
				(*x)++;
				rtn = D_KEEP_GOING;
				break;
			}
			else if (local_map[(*y) - 1][*x] == road + temp)
			{
				/* P1-3 : FIND TOP */
				(local_map[*y][*x]) = (local_map[*y][*x]) + 1 + temp;
				(*y)--;
				rtn = D_KEEP_GOING;
				break;
			}
			else if (local_map[*y][(*x) - 1] == road + temp)
			{
				/* P1-4 : FIND LEFT */
				(local_map[*y][*x]) = (local_map[*y][*x]) + 1 + temp;
				(*x)--;
				rtn = D_KEEP_GOING;
				break;
			}
		}
	}
	else
	{
		for (int temp = 1; temp < 16; temp++)
		{
			/* PRIORITY1 : FIND ROAD */
			if (local_map[(*y) + 1][*x] == road + temp)
			{
				/* P1-1 : FIND BOTTOM */
				(local_map[*y][*x]) = 70;
				(*y)++;
				rtn = D_KEEP_GOING;
				break;
			}
			else if (local_map[*y][(*x) + 1] == road + temp)
			{
				/* P1-2 : FIND RIGHT */
				(local_map[*y][*x]) = 70;
				(*x)++;
				rtn = D_KEEP_GOING;
				break;
			}
			else if (local_map[(*y) - 1][*x] == road + temp)
			{
				/* P1-3 : FIND TOP */
				(local_map[*y][*x]) = 70;
				(*y)--;
				rtn = D_KEEP_GOING;
				break;
			}
			else if (local_map[*y][(*x) - 1] == road + temp)
			{
				/* P1-4 : FIND LEFT */
				(local_map[*y][*x]) = 70;
				(*x)--;
				rtn = D_KEEP_GOING;
				break;
			}
		}
	}
#if 0
	/* PRIORITY2 : FIND '1' VISITED */
	else if (local_map[(*y) + 1][*x] == (road + 1))
	{
		/* P2-1 : FIND BOTTOM */
		(local_map[*y][*x])++;
		(*y)++;
		rtn = D_KEEP_GOING;
	}
	else if (local_map[*y][(*x) + 1] == (road + 1))
	{
		/* P2-2 : FIND RIGHT */
		(local_map[*y][*x])++;
		(*x)++;
		rtn = D_KEEP_GOING;
	}
	else if (local_map[(*y) - 1][*x] == (road + 1))
	{
		/* P2-3 : FIND TOP */
		(local_map[*y][*x])++;
		(*y)--;
		rtn = D_KEEP_GOING;
	}
	else if (local_map[*y][(*x) - 1] == (road + 1))
	{
		/* P2-4 : FIND LEFT */
		(local_map[*y][*x])++;
		(*x)--;
		rtn = D_KEEP_GOING;
	}
#endif
	if ((*y) == (size - 1) || (*x) == (size - 1))
	{
		(local_map[*y][*x])++;
		rtn = D_FIND_END;
	}
	return rtn;
}