
#include "maze_main.h"

#define DOOR_SIZE 10
#define MAP_SIZE_MIN 10
#define MAP_SIZE_MAX 30

#define WALL_SIMBOL 10
#define ROAD_SIMBOL 20
#define MAN_SIMBOL 80

#define WORKING_LEFT 0x10
#define WORKING_DOWN 0x20
#define WORKING_RIGHT 0x40
#define WORKING_UP 0x80

#define MAZE_MAP_POS_X 0
#define MAZE_MAP_POS_Y 8
#define MAZE_MAP_POS {MAZE_MAP_POS_X,MAZE_MAP_POS_Y}
#define MAP_DRAW_SPEED 100

static char DOOR[DOOR_SIZE][DOOR_SIZE] = {
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },	// 5
	{ 0,0,0,0,0,1,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 }		// 10
};

static void p_clear(void)
{
	system("cls");
}
static void clear_doublearray(char **arr, int size)
{
	int i = 0, j = 0;
	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			arr[i][j] = 0;
		}
	}
}

static void door_draw(int size) {
	int index_for_draw_i;
	int index_for_draw_j;

	COORD _pos = { 0,0 };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), _pos);

	for (index_for_draw_i = 0; index_for_draw_i < size + MAZE_MAP_POS_Y; index_for_draw_i++)
	{
		for (index_for_draw_j = 0; index_for_draw_j < size; index_for_draw_j++)
		{
			printf("��");
		}
		Sleep(MAP_DRAW_SPEED);
		printf("\n");
	}

	//_pos.X = MAZE_MAP_POS_X;
	//_pos.Y = MAZE_MAP_POS_Y;
	_pos.X = 0;
	_pos.Y = 0;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), _pos);

	for (index_for_draw_i = 0; index_for_draw_i < size + MAZE_MAP_POS_Y; index_for_draw_i++)
	{
		for (index_for_draw_j = 0; index_for_draw_j < size; index_for_draw_j++)
		{
			printf("��");
		}
		Sleep(MAP_DRAW_SPEED);
		printf("\n");
	}
}
static void working_direction(int post_x, int post_y, int last_x, int last_y, char **MazeMapdirection)
{
	int x_direction;
	int y_direction;

	x_direction = last_x - post_x;
	y_direction = last_y - post_y;

	MazeMapdirection[post_y][post_x] = MazeMapdirection[post_y][post_x] + 1;

	if (x_direction == 1)
	{
		MazeMapdirection[post_y][post_x] |= WORKING_RIGHT;
		MazeMapdirection[last_y][last_x] |= WORKING_LEFT;
	}
	else if (x_direction == -1)
	{
		MazeMapdirection[post_y][post_x] |= WORKING_LEFT;
		MazeMapdirection[last_y][last_x] |= WORKING_RIGHT;
	}
	if (y_direction == 1)
	{
		MazeMapdirection[post_y][post_x] |= WORKING_DOWN;
		MazeMapdirection[last_y][last_x] |= WORKING_UP;
	}
	else if (y_direction == -1)
	{
		MazeMapdirection[post_y][post_x] |= WORKING_UP;
		MazeMapdirection[last_y][last_x] |= WORKING_DOWN;
	}
}
static int man_move_modify(char **MazeMapBoard, int size, int man_X_pos, int man_Y_pos, char **MazeMapdirection)
{
	int index_for_draw_i;
	int index_for_draw_j;
	int X_pos_modify;
	int Y_pos_modify;

	int find_flag = 0;


	// ������ �ִ� ��ġ Ȯ��
	if (man_X_pos < 0 || man_Y_pos < 0 || man_X_pos>size - 1 || man_Y_pos > size - 1)
	{
		return 0; // �߸��� �̵�����Դϴ�.
	}
	else
	{
		for (index_for_draw_i = 0; index_for_draw_i < size; index_for_draw_i++)
		{
			for (index_for_draw_j = 0; index_for_draw_j < size; index_for_draw_j++)
			{
				if (MazeMapBoard[index_for_draw_i][index_for_draw_j] == MAN_SIMBOL)
				{
					find_flag = 1;
					break;
				}
			}
			if (find_flag)
			{
				break;
			}
		}
	}
	if (find_flag)
	{
		X_pos_modify = abs(index_for_draw_j - man_X_pos);
		Y_pos_modify = abs(index_for_draw_i - man_Y_pos);
		//printf("����ɺ��� ã�ҳ�?? %d, %d", man_Y_pos, man_X_pos);
		// ����� ������ ��ĭ���� �������� �Ѵ�
		if (X_pos_modify + Y_pos_modify == 1)
		{
			//printf("��ĭ�� ��������??");
			// ����� ������ �����θ� �����ٴ� �� �ִ�
			if (MazeMapBoard[man_Y_pos][man_X_pos] == ROAD_SIMBOL)
			{
				//printf("���ΰ�??");
				COORD _pos = MAZE_MAP_POS;
				_pos.X = MAZE_MAP_POS_X + (man_X_pos * 2);
				_pos.Y = MAZE_MAP_POS_Y + man_Y_pos;
				SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), _pos);
				printf("��");
				MazeMapBoard[man_Y_pos][man_X_pos] = MAN_SIMBOL;
				Sleep(30);

				working_direction(index_for_draw_j, index_for_draw_i, man_X_pos, man_Y_pos, MazeMapdirection);
				_pos.X = MAZE_MAP_POS_X + (index_for_draw_j * 2);
				_pos.Y = MAZE_MAP_POS_Y + index_for_draw_i;
				SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), _pos);
				MazeMapBoard[index_for_draw_i][index_for_draw_j] = ROAD_SIMBOL;
				switch (MazeMapdirection[index_for_draw_i][index_for_draw_j] & 0xF0)
				{
				case WORKING_LEFT:
					printf("��");
					break;
				case WORKING_UP:
					printf("��");
					break;
				case WORKING_RIGHT:
					printf("��");
					break;
				case WORKING_DOWN:
					printf("��");
					break;
				case WORKING_LEFT + WORKING_UP:
					printf("��");
					break;
				case WORKING_LEFT + WORKING_RIGHT:
					printf("��");
					break;
				case WORKING_LEFT + WORKING_DOWN:
					printf("��");
					break;
				case WORKING_UP + WORKING_RIGHT:
					printf("��");
					break;
				case WORKING_UP + WORKING_DOWN:
					printf("��");
					break;
				case WORKING_RIGHT + WORKING_DOWN:
					printf("��");
					break;
				case WORKING_LEFT + WORKING_UP + WORKING_RIGHT:
					printf("��");
					break;
				case WORKING_LEFT + WORKING_UP + WORKING_DOWN:
					printf("��");
					break;
				case WORKING_LEFT + WORKING_RIGHT + WORKING_DOWN:
					printf("��");
					break;
				case WORKING_UP + WORKING_RIGHT + WORKING_DOWN:
					printf("��");
					break;
				case WORKING_LEFT + WORKING_UP + WORKING_RIGHT + WORKING_DOWN:
					printf("��");
					break;
				default:
					printf("��");
					break;
				}
				Sleep(100);
				if (MazeMapdirection[index_for_draw_i][index_for_draw_j] % 16 == 0)
				{
					return 0; // ���ڸ��� �ʹ� ���� �Դٰ��� ����
				}
				return 1;
			}
			printf("���� �ƴѰ�??\n");
		}
		//printf("��ĭ�� ��������?? %d, %d, %d, %d\n", index_for_draw_i, index_for_draw_j, man_Y_pos, man_X_pos);
	}
	else
	{
		COORD _pos = MAZE_MAP_POS;
		_pos.X = MAZE_MAP_POS_X + (man_X_pos * 2);
		_pos.Y = MAZE_MAP_POS_Y + man_Y_pos;
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), _pos);
		printf("��");
		MazeMapBoard[man_Y_pos][man_X_pos] = MAN_SIMBOL;
		Sleep(100);
		return 1;
	}
	return 0; // �߸��� �̵�����Դϴ�.
}
static void maze_map_draw(char **MazeMapBoard, int size)
{
	int index_for_draw_i;
	int index_for_draw_j;

	COORD _pos = MAZE_MAP_POS;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), _pos);

	for (index_for_draw_i = 0; index_for_draw_i < size; index_for_draw_i++)
	{
		for (index_for_draw_j = 0; index_for_draw_j < size; index_for_draw_j++)
		{
			if (MazeMapBoard[index_for_draw_i][index_for_draw_j] == WALL_SIMBOL)
			{
				printf("��");
			}
			else if (MazeMapBoard[index_for_draw_i][index_for_draw_j] == ROAD_SIMBOL)
			{
				printf("  ");
			}
#if 0 // ���ʿ� �ʿ� ���� �׸��� �׸�
			else if (MazeMapBoard[index_for_draw_i][index_for_draw_j] == MAN_SIMBOL)
			{
				printf("��");
			}
#endif
			else
			{
				printf("��");
			}
		}
		Sleep(MAP_DRAW_SPEED);
		printf("\n");
	}
}

static momo_printf(char *str, int size)
{
	int a;
	COORD _pos = MAZE_MAP_POS;
	_pos.Y = MAZE_MAP_POS_Y + size + 2;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), _pos);
	printf("%s\n", str);
	printf("����� Ȯ���Ͻÿ�!!!!\n");
	printf("0�� �Է��ϰ� ���͸� ġ�ÿ�!!!!");
	scanf_s("%d", &a);
}

static void find_map_road(char **MazeMapBoard, int size, int map_count, char **MazeMapdirection)
{
	int man_X_pos = 0;
	int man_Y_pos = 0;
	int maze_fining = 0;

	do
	{
		//maze_fining = get_man_pos_map(MazeMapBoard, size, WALL_SIMBOL, ROAD_SIMBOL, &man_X_pos, &man_Y_pos, map_count);
		maze_fining = Mirro_algorithm(MazeMapBoard, ROAD_SIMBOL, WALL_SIMBOL, &man_X_pos, &man_Y_pos, map_count, size);
		if (maze_fining)
		{
			//printf("%d,%d", man_Y_pos, man_X_pos);
			if (man_move_modify(MazeMapBoard, size, man_X_pos, man_Y_pos, MazeMapdirection))
			{
				// OK
				//break;
			}
			else
			{
				// NG �̷�ã�� �˰������� ���� �ƴ� ������ ���ų� ������ ������ �����̰ų� �������� ���ϰų� �Ͽ���
				// !!
				momo_printf("!!!!�̷�ã�� �˰����� ����!!!!!", size);
				break;
			}
		}
		else
		{
			man_move_modify(MazeMapBoard, size, man_X_pos, man_Y_pos, MazeMapdirection);
			momo_printf("!!!!�ⱸ�� �߰�!!!!", size);
			break;
		}
	} while (1);
	return;
}

static void momo_memcopy(char **MazeMapBoard_temp, char **MazeMapBoard, int size)
{
	int index_for_draw_i;
	int index_for_draw_j;

	for (index_for_draw_i = 0; index_for_draw_i < size; index_for_draw_i++)
	{
		for (index_for_draw_j = 0; index_for_draw_j < size; index_for_draw_j++)
		{
			MazeMapBoard_temp[index_for_draw_i][index_for_draw_j] = MazeMapBoard[index_for_draw_i][index_for_draw_j];
		}
	}
}

int main()
{
	// �̷� ���� ���� ���� ����
	char **MazeMapBoard;// [D_COM_BOARD_WIDTH][D_COM_BOARD_HEIGHT] = { D_COM_BOARD_INIT_VALUE, };
	char **MazeMapBoard_temp;// [D_COM_BOARD_WIDTH][D_COM_BOARD_HEIGHT] = { D_COM_BOARD_INIT_VALUE, };
	char **MazeMapdirection;
	int size = 0;
	int menu = 0;
	int man_X_pos = 0;
	int man_Y_pos = 0;

	printf("[Input map size] (low:%d/Max%d) : ", MAP_SIZE_MIN, MAP_SIZE_MAX);
	scanf_s("%d", &size);

	if (size > MAP_SIZE_MAX) { size = MAP_SIZE_MAX; }
	else if (size < MAP_SIZE_MIN) { size = MAP_SIZE_MIN; }


	MazeMapBoard = (char**)malloc(sizeof(char*) * size);
	if (MazeMapBoard == NULL)
	{
		return -1;
	}
	for (int i = 0; i < size; i++)
	{
		MazeMapBoard[i] = (char*)malloc(sizeof(char) * size);
		if (MazeMapBoard[i] == NULL)
		{
			return -1;
		}
	}
	MazeMapBoard_temp = (char**)malloc(sizeof(char*) * size);
	if (MazeMapBoard_temp == NULL)
	{
		return -1;
	}
	for (int i = 0; i < size; i++)
	{
		MazeMapBoard_temp[i] = (char*)malloc(sizeof(char) * size);
		if (MazeMapBoard_temp[i] == NULL)
		{
			return -1;
		}
	}
	MazeMapdirection = (char**)malloc(sizeof(char*) * size);
	if (MazeMapdirection == NULL)
	{
		return -1;
	}
	for (int i = 0; i < size; i++)
	{
		MazeMapdirection[i] = (char*)malloc(sizeof(char) * size);
		if (MazeMapdirection[i] == NULL)
		{
			return -1;
		}
	}
	door_draw(size);
	clear_doublearray(MazeMapBoard_temp, size);
PLAY_AGAIN:
	p_clear();
	clear_doublearray(MazeMapBoard, size);
	clear_doublearray(MazeMapdirection, size);
	momo_memcopy(MazeMapBoard, MazeMapBoard_temp, size);
	printf("#################################\n");
	printf("##1. �̷� ���� �ٽ� ��������\n");
	printf("##2. ������ �̷� Ž���ϱ�\n");
	printf("##3. Ž���� ����� �ѹ��� ��ã��\n");
	printf("##4. ��ã�� �ʱ�ȭ\n");
	printf("##5. ����\n");

	// �빮�� �׸��� �Լ�
	maze_map_draw(MazeMapBoard_temp, size);


	scanf_s("%d", &menu);

	switch (menu)
	{
	case 1:
		// ������ �޾ƿ� �Լ� ȣ��
		//get_maze_map(MazeMapBoard, size, WALL_SIMBOL, ROAD_SIMBOL);
		create_map(MazeMapBoard, size, ROAD_SIMBOL, WALL_SIMBOL);
		//memcpy(MazeMapBoard_temp, MazeMapBoard, size*size);
		//memmove(MazeMapBoard_temp, MazeMapBoard, size*size);
		momo_memcopy(MazeMapBoard_temp, MazeMapBoard, size);
		// �޾ƿ� ������ �׸��� �Լ�
		//maze_map_draw(MazeMapBoard_temp, size);		
		break;
	case 2:
		// ��ã�� �Լ� ��Ÿ鼭 ã��
		find_map_road(MazeMapBoard, size, 1, MazeMapdirection);
		break;
	case 3:
		// ��ã�� �Լ� �ѹ��� ã��
		find_map_road(MazeMapBoard, size, 2, MazeMapdirection);
		break;
	case 4:
		// ��ã�� �Լ� �ʱ�ȭ
		//find_map_road(MazeMapBoard, size, 3, MazeMapdirection);
		Mirro_algorithm(MazeMapBoard, ROAD_SIMBOL, WALL_SIMBOL, &man_X_pos, &man_Y_pos, 3, size);
		break;
	case 5:
		goto PLAY_END;
		break;
	default:
		break;
	}
	goto PLAY_AGAIN;


PLAY_END:
	for (int i = 0; i < size; i++)
	{
		free(MazeMapBoard[i]);
	}
	free(MazeMapBoard);
	for (int i = 0; i < size; i++)
	{
		free(MazeMapBoard_temp[i]);
	}
	free(MazeMapBoard_temp);

	for (int i = 0; i < size; i++)
	{
		free(MazeMapdirection[i]);
	}
	free(MazeMapdirection);
	//ck_com_Set_Positon_And_Draw_Stone(OmokBoard, 20, 10, D_COM_FINISH_FLAG);
}
