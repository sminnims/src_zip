//#include "stdafx.h"
//#include "windows.h"

#include "maze_main.h"

#define EXCUTE_SELF 0
#define UP_FAIL 0x0001
#define DOWN_FAIL 0x0010
#define LEFT_FAIL 0x0100
#define RIGHT_FAIL 0x1000
#define FULL_BLOCK 0x1111

//void create_map(char** arr, int size, char road, char wall);
static void draw(char** arr, int size, char road, char wall);
int go_to_up(char** arr, int *row, int *col, int size, char sym);
int go_to_down(char** arr, int *row, int *col, int size, char sym);
int go_to_left(char** arr, int *row, int *col, int size, char sym);
int go_to_right(char** arr, int *row, int *col, int size, char sym);
void go_to_random(char** arr, int *row, int *col, int size, char sym);

#if EXCUTE_SELF
int main()
{
	int size = 20;
	int i = 0, j = 0;
	char** arr = NULL;
	char road = 'O', wall = 'X';
	char in[10];
	memset(in, 0, sizeof(in));
	/* alloc array */
	arr = (char**)malloc(sizeof(char*) * size);
	for (i = 0; i < size; i++)
	{
		arr[i] = (char*)malloc(sizeof(char) * size);
	}
REGAME:
	create_map(arr, size, road, wall);
	draw(arr, size, road, wall);
GET_INPUT:
	printf("more? [y/n] :");
	scanf("%s", in);
	if (strcmp(in, "y") == 0)
	{
		goto REGAME;
	}
	else if (strcmp(in, "n") == 0)
	{
		goto P_END;
	}
	else
	{
		printf("wrong input\n");
		goto GET_INPUT;
	}
P_END:
	/* free array */
	for (i = 0; i < size; i++)
	{
		free(arr[i]);
	}
	free(arr);
	return 0;
}
#endif
static void draw(char** arr, int size, char road, char wall)
{
	int i = 0, j = 0;
	system("cls");
	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			if (arr[i][j] == road)
			{
				printf("  ");
			}
			else
			{
				printf("��");
			}
		}
		printf("\n");
	}
}
extern void create_map(char** arr, int size, char road, char wall)
{
	int i = 0, j = 0;
	int rnd_val = 0;
	int row = 0, col = 0;
	int rtn = 0;
	unsigned int up = 0, down = 0, left = 0, right = 0;
	static unsigned int seed = 0;
	unsigned int block_bit = 0;
	int start_col = 0;
	unsigned int back_cnt = 0;
	/* clear map : to wall */
	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			arr[i][j] = wall;
		}
	}
	srand((unsigned)time(NULL));
	rnd_val = rand() % (size - 1);
	if (rnd_val == 0 || rnd_val == size - 1)
		rnd_val = 1;
	col = rnd_val;
	arr[row][col] = road;
	row++;
	arr[row][col] = road;
	start_col = col;
	do
	{
	MAKE_ROAD:
		rnd_val = (rand() * seed) % 4;
		switch (rnd_val)
		{
		case 0:
			rtn = go_to_up(arr, &row, &col, size, road);
			seed += 3;
			if (rtn == 0)
				up++;
			else
				block_bit = block_bit | UP_FAIL;
			break;
		case 1:
			rtn = go_to_down(arr, &row, &col, size, road);
			seed += 5;
			if (rtn == 0)
				down++;
			else
				block_bit = block_bit | DOWN_FAIL;
			break;
		case 2:
			rtn = go_to_left(arr, &row, &col, size, road);
			seed += 7;
			if (rtn == 0)
				left++;
			else
				block_bit = block_bit | LEFT_FAIL;
			break;
		case 3:
		default:
			rtn = go_to_right(arr, &row, &col, size, road);
			seed += 11;
			if (rtn == 0)
				right++;
			else
				block_bit = block_bit | RIGHT_FAIL;
			break;
		}
		if (rtn == 0)
		{
			arr[row][col] = road;
			//draw(arr, size, road, wall);
			block_bit = 0;
		}
		if (block_bit == FULL_BLOCK)
		{
		MAKE_BRANCH_ROAD:
			go_to_random(arr, &row, &col, size, road);
			back_cnt++;
			block_bit = 0;
		}
	} while (row < (size - 1));

	if (back_cnt < 3)
	{
		/* �бⰡ �ʹ� ����. �ⱸ ���� �ٽ� �׸��� ���� */
		arr[row][col] = wall;
		row--;
		col--;
		goto MAKE_BRANCH_ROAD;
	}


	printf("[UP:%d DOWN:%d LEFT:%d RIGHT:%d]\n", up, down, left, right);
}
void go_to_random(char** arr, int *row, int *col, int size, char sym)
{
	int r_val = 0, c_val = 0;
	unsigned int cnt = 0;
	do
	{
		r_val = rand() % (size - 1);
		c_val = (rand() * r_val) % (size - 1);
		cnt++;
	} while (arr[r_val][c_val] != sym);
	*row = r_val;
	*col = c_val;
}
int go_to_up(char** arr, int *row, int *col, int size, char sym)
{
	int y = *row;
	int x = *col;
	if (y - 1 < 1)
	{
		return -1;
	}
	else
	{
		if (arr[y - 1][x] == sym)
		{
			//return -1;
		}
		if ((x - 1 >= 0) && (arr[y - 1][x - 1] == sym))
		{
			return -1;
		}

		if ((x + 1 < size) && (arr[y - 1][x + 1] == sym))
		{
			return -1;
		}
		if ((y - 2 >= 0) && (arr[y - 2][x] == sym))
		{
			return -1;
		}
		y--;
		*row = y;
		return 0;
	}
}
int go_to_down(char** arr, int *row, int *col, int size, char sym)
{
	int y = *row;
	int x = *col;
	if (y + 1 > size)
	{
		return -1;
	}
	else
	{
		if (arr[y + 1][x] == sym)
		{
			//return -1;
		}
		if ((x - 1 >= 0) && (arr[y + 1][x - 1] == sym))
		{
			return -1;
		}
		if ((x + 1 < size) && (arr[y + 1][x + 1] == sym))
		{
			return -1;
		}
		if ((y + 2 < size) && (arr[y + 2][x] == sym))
		{
			return -1;
		}
		y++;
		*row = y;
		return 0;
	}
}
int go_to_left(char** arr, int *row, int *col, int size, char sym)
{
	int y = *row;
	int x = *col;
	if (x - 1 < 1)
	{
		return -1;
	}
	else
	{
		if (arr[y][x - 1] == sym)
		{
			//return -1;
		}
		if ((y - 1 >= 0) && (arr[y - 1][x - 1] == sym))
		{
			return -1;
		}
		if ((y + 1 < size) && (arr[y + 1][x - 1] == sym))
		{
			return -1;
		}
		if ((x - 2 >= 1) && (arr[y][x - 2] == sym))
		{
			return -1;
		}
		x--;
		*col = x;
		return 0;
	}
}
int go_to_right(char** arr, int *row, int *col, int size, char sym)
{
	int y = *row;
	int x = *col;
	if (x + 1 > size - 2)
	{
		return -1;
	}
	else
	{
		if (arr[y][x - 1] == sym)
		{
			//return -1;
		}
		if ((y - 1 >= 0) && (arr[y - 1][x + 1] == sym))
		{
			return -1;
		}
		if ((y + 1 < size) && (arr[y + 1][x + 1] == sym))
		{
			return -1;
		}
		if ((x + 2 < size - 2) && (arr[y][x + 2] == sym))
		{
			return -1;
		}
		x++;
		*col = x;
		return 0;
	}
}