#include "mydef.h"
#ifdef _WIN32_
	#include <windows.h>
#endif
//////////////////////////////////////////
/* define / structure / enum		*/
//////////////////////////////////////////
//////////////////////////////////////////
/* proto type 				*/
//////////////////////////////////////////

extern int p1_go(char **arr, int size, char sym);
extern int p2_go(char **arr, int size, char sym);

int alloc_doublearray(char **arr, int size);
void free_doublearray(char **arr, int size);
void clear_doublearray(char **arr, int size);
void draw(char **arr, int size, char* str);

int check_result(char** arr, char** save_arr, int size, char sym, int rtn);
int check_winner(char** arr, int size, char sym);
void p_sleep(int sec);
//////////////////////////////////////////
/* function 				*/
//////////////////////////////////////////
int main()
{
	int size = 0; /* col, raw size */
	char p1 = '@';
	char p2 = 'O';
	int rtn = 0;
	int i = 0, j = 0;
	char input = 0;
	char **arr;
	char **save_arr;
	system("clear");
	printf("[Input Row*Col value] (low:10/Max19) : ");
	scanf("%d", &size);
	if(size > 19) size = 19;
	else if(size < 10) size = 10;

	arr = (char**)malloc( sizeof(char*) * size );
	if(arr == NULL)
	{
		return -1;
	}
	for( i = 0; i < size; i++)
	{
		arr[i] = (char*)malloc( sizeof(char) * size );
		if(arr[i] == NULL)
		{
			return -1;
		}
	}
	save_arr = (char**)malloc( sizeof(char*) * size );
	if(save_arr == NULL)
	{
		return -1;
	}
	for( i = 0; i < size; i++)
	{
		save_arr[i] = (char*)malloc( sizeof(char) * size );
		if(save_arr[i] == NULL)
		{
			return -1;
		}
	}

PLAY_AGAIN:
	clear_doublearray(arr, size);
	clear_doublearray(save_arr, size);
	system("clear");
	/* draw ready */
	printf("[O-MOK Play]\n");
	printf("[Player 1 : %c / Player 2 : %c]\n", p1, p2);
	draw(arr, size, READY_STR);
	while(1)
	{
		/* save original array before play */
		for(i=0;i<size;i++) 
		{	
			for(j=0;j<size;j++)
			{
				save_arr[i][j] = arr[i][j];
			}
		}
		rtn = p1_go(arr, size, p1);
		if( check_result(arr, save_arr, size, p1, rtn) == OMOK_PLAY )
		{
			/* save original array before play */
			for(i=0;i<size;i++)
			{	
				for(j=0;j<size;j++)
				{
					save_arr[i][j] = arr[i][j];
				}
			}	
			rtn = p1_go(arr, size, p2);
			if ( check_result(arr, save_arr, size, p2, rtn) == OMOK_PLAY )
			{
				continue;
			}
		}
		/* check play more */
		{
MORE_GAME:
			printf("play onther game? [y/n] : ");
			scanf("%s", &input);
			if(strcmp(&input, "n") == 0)
			{
				break;
			}
			else if(strcmp(&input, "y") == 0)
			//else if(input == 'y')
			{
				goto PLAY_AGAIN;
			}
			else
			{
				printf("wrong input. please input  y or n\n");
				goto MORE_GAME;
			}
		}
		
	}

	/* end */
	for(i = 0; i < size; i ++)
	{
		free(arr[i]);
	}
	free(arr);
	return 0;
}
#if TEST_MODE
int p1_go(char** arr, int size, char sym)
{
	int rtn = OMOK_PLAY;
	int i = 0, j = 0;
	printf("[P1 GO!]\n");
	for(i = 0; i < size; i++)
	{
		for(j=0;j<size;j++)
		{
			arr[i][j] = sym;
		}
	}
	return OMOK_WIN;
	return rtn;
}

int p2_go(char** arr, int size, char sym)
{
	int rtn = OMOK_PLAY;
	printf("[P2 GO!]\n");
	int i = 0;
	for(i = 0; i < 5; i++)
	{
		arr[2+i][3] = sym;
	}
	arr[4][3] = '@';
	//return rtn;
	return OMOK_WIN;
}
#endif
int check_result(char** arr, char** save_arr, int size, char sym, int result)
{
	int rtn = OMOK_PLAY;
	int i, j = 0;
	int player = 0, opponent = 0;
	int play_counter = 0;	

	player = (sym == '@') ? 1 : 2;
	opponent = (player == 1) ? 2 : 1;
	draw(arr, size, PLAY_STR);

	for(i = 0; i < size; i++)
	{
		for( j = 0; j < size; j++)
		{
			if(arr[i][j] != save_arr[i][j])
			{
				play_counter++;
			}
		}
	}

	if(play_counter > 1)
	{
		printf("[Player %d was cheated, set 2pieces at one time]\n", player);
		printf("[Player %d Win!!]\n", opponent);
		rtn = OMOK_WIN;
	}
	else
	{

	switch(result)
	{
		case OMOK_DRAW:
			draw(arr, size, DRAW_STR);
	
			for(i = 0; i < size; i++)
			{
				for(j = 0; j < size; j++)
				{
					printf("[Player %d declared Draw]\n", player);
					if(arr[i][j] == '-')
					{
						printf("[Draw? You are Wrong, Player %d]\n", player);	/* draw lose? */
						printf("[Player %d Unearned Win!]\n", opponent);	
						rtn = OMOK_CHEAT;						
						break;					
			 		}
				}
				if(rtn != OMOK_PLAY)
					break;
			}
			break;
		case OMOK_WIN:			
			draw(arr, size, WIN_STR);
			printf("[Player %d declared Win]\n", player);
			if( check_winner(arr, size, sym) != OMOK_WIN )
			{
				printf("[Win? Yor are Wrong, Player %d]\n", player);
				printf("[Player %d Unearned Win!]\n", opponent);
				rtn = OMOK_CHEAT;
			}
			else
			{
				printf("[Ok, Player %d Win!!]\n", player);
				rtn = OMOK_WIN;
			}
			break;
				
		case OMOK_PLAY:
			break;
		default:				
			printf("[INPUT ERROR!][%d]\n", rtn);
			rtn = OMOK_ERROR;
			break;
	}
	
	} /* if(play_counter > 1) {} else */
	return rtn;
}

int check_winner(char **arr, int size, char sym)
{
	int rtn = OMOK_DRAW;
	int i = 0, j = 0;
	int x = 1, y = 1;
	int counter = 0;

	for(i = 0; i < size; i++)
	{
		for(j = 0; j < size; j++)
		{
			if(arr[i][j] == sym)
			{
				counter = 1;
				/* check row */
				for(x = 1; x < size-j-1; x++)
				{
					if(arr[i][j+x] == sym)
					{
						counter++;
						if(counter == 5)
						{
							printf("Row Win\n");
							rtn = OMOK_WIN;
							p_sleep(1);
							goto WIN;
						}
					}
					else
					{
						counter = 1;
						break;
					}
				}
				/* check column */
				for( x = 1; x < size-i-1; x++)
				{
								
					if(arr[i+x][j] == sym)
					{
						counter++;
						if(counter == 5)
						{
							printf("Column Win\n");
							rtn = OMOK_WIN;
							p_sleep(1);
							goto WIN;
						}
					}
					else
					{
						counter = 1;
						break;
					}
			
				}				
				/* chechk diagonal */
				y = ( i > j ) ? i : j;
				for( x = 1; x < size -y -1; x++)
				{
					if(arr[i+x][j+x] == sym)
					{
						counter++;
						if(counter == 5)
						{	
							printf("Diagonal Win\n");
							rtn = OMOK_WIN;
							p_sleep(1);
							goto WIN;
						}
					}
					else
					{
						counter = 1;
						break;
					}
				}
			}
			
		}
	}
WIN:	
	return rtn;
}

void draw(char** arr, int size, char *str)
{
	int i =0, j = 0;

//	system("clear");
#ifdef _WIN32_
	COORD _pos = { 0, 2 }
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), _pos);
#else
	printf("\033[%dd\033[%dG", 3, 0);
#endif
	printf("[%s]\n", str);

	for(i = 0; i < size; i++)
	{
		for(j = 0; j < size; j++)
		{
			printf("[%c]", arr[i][j]);
		}
		printf("\n");
	}
	if( !strcmp(str, PLAY_STR)|| !strcmp(str, READY_STR) )
		p_sleep(1);
	return;
}
int alloc_doublearray(char **arr, int size)
{
	int i = 0;
	arr = (char**)malloc( sizeof(char*) * size );
	if(arr == NULL)
	{
		return -1;
	}
	for( i = 0; i < size; i++)
	{
		arr[i] = (char*)malloc( sizeof(char) * size );
		if(arr[i] == NULL)
		{
			return -1;
		}
	}

	return 0;
}
void free_doublearray(char **arr, int size)
{
	int i = 0;
	
	for(i = 0; i < size; i++)
	{
		free(arr[i]);
	}
	free(arr);
}

void clear_doublearray(char **arr, int size)
{
	int i = 0, j = 0;
	for(i = 0; i < size; i++)
	{
		for(j = 0; j < size; j++)
		{
			arr[i][j] = '-';
		}
	}


}

void p_sleep(int sec)
{
#if _WIN32_
	Sleep(sec*1000);
#else
	sleep(sec);
#endif
}
