#ifndef _MYDEF_H_
#define _MYDEF_H_

#include <stdlib.h>
#include <stdio.h>


#define READY_STR	"Ready To Start"
#define PLAY_STR	"Now Playing...."
#define DRAW_STR	"Draw!!!!!!!!!!"
#define WIN_STR		"Finish!!!!!!!!"
#define TEST_MODE	0
enum
{
	OMOK_PLAY	 = 0x00
	, OMOK_WIN	= 0x01
	, OMOK_DRAW	= 0x02
	, OMOK_CHEAT	= 0x03
	, OMOK_ERROR	= 0x04
};

#endif /* #ifndef _MYDEF_H_ */
